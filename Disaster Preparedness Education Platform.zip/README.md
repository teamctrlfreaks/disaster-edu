
  # Disaster Preparedness Education Platform

  This is a code bundle for Disaster Preparedness Education Platform. The original project is available at https://www.figma.com/design/sMUdWTl3kKU3rI0cKHy2rh/Disaster-Preparedness-Education-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
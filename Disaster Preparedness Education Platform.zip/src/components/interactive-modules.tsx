import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Play, 
  BookOpen, 
  Trophy, 
  Clock, 
  CheckCircle, 
  Star,
  ArrowRight,
  Zap,
  Target,
  Award,
  Mountain,
  Waves,
  Flame,
  Wind,
  AlertTriangle,
  Users
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface InteractiveModulesProps {
  userType: 'student' | 'teacher' | 'community' | null;
}

export function InteractiveModules({ userType }: InteractiveModulesProps) {
  const [selectedModule, setSelectedModule] = useState<string | null>(null);
  const [currentScenario, setCurrentScenario] = useState(0);

  // Mock module data
  const modules = [
    {
      id: 'earthquake',
      title: 'Earthquake Safety',
      description: 'Learn how to prepare for and respond to earthquakes',
      icon: Mountain,
      color: 'red',
      difficulty: 'Beginner',
      duration: '30 min',
      completionRate: 85,
      enrolled: 156,
      lessons: 8,
      scenarios: [
        {
          title: 'At School During an Earthquake',
          description: 'You feel the ground shaking during class. What do you do first?',
          options: [
            'Run outside immediately',
            'Duck, Cover, and Hold On under your desk',
            'Stand in the doorway',
            'Look out the window to see what\'s happening'
          ],
          correct: 1,
          explanation: 'Drop to your hands and knees, take cover under a sturdy desk or table, and hold on to your shelter while protecting your head and neck.'
        }
      ]
    },
    {
      id: 'flood',
      title: 'Flood Response',
      description: 'Understanding flood risks and safety measures',
      icon: Waves,
      color: 'blue',
      difficulty: 'Intermediate',
      duration: '25 min',
      completionRate: 72,
      enrolled: 134,
      lessons: 6,
      scenarios: [
        {
          title: 'Flash Flood Warning',
          description: 'Heavy rains have caused flooding in your area. Your family needs to evacuate. What should you do first?',
          options: [
            'Gather all valuable items',
            'Turn off utilities and grab emergency kit',
            'Wait to see if the water recedes',
            'Drive through the flooded street'
          ],
          correct: 1,
          explanation: 'Turn off utilities to prevent electrical hazards and grab your pre-prepared emergency kit before evacuating to higher ground.'
        }
      ]
    },
    {
      id: 'fire',
      title: 'Fire Safety',
      description: 'Fire prevention and emergency evacuation procedures',
      icon: Flame,
      color: 'orange',
      difficulty: 'Beginner',
      duration: '20 min',
      completionRate: 91,
      enrolled: 189,
      lessons: 5,
      scenarios: [
        {
          title: 'Kitchen Fire Emergency',
          description: 'A pan catches fire while cooking. What is the safest action?',
          options: [
            'Pour water on the fire',
            'Turn off heat source and cover with lid',
            'Try to move the pan outside',
            'Open windows for ventilation'
          ],
          correct: 1,
          explanation: 'Turn off the heat source and cover the pan with a lid to smother the fire. Never use water on a grease fire.'
        }
      ]
    },
    {
      id: 'cyclone',
      title: 'Cyclone Preparedness',
      description: 'Preparing for and surviving tropical cyclones',
      icon: Wind,
      color: 'purple',
      difficulty: 'Advanced',
      duration: '35 min',
      completionRate: 68,
      enrolled: 98,
      lessons: 10,
      scenarios: [
        {
          title: 'Cyclone Shelter Decision',
          description: 'A Category 3 cyclone is approaching. Should you stay home or evacuate?',
          options: [
            'Stay home and board up windows',
            'Evacuate to a designated shelter',
            'Go to a friend\'s house inland',
            'Wait and see how strong it gets'
          ],
          correct: 1,
          explanation: 'Follow evacuation orders and go to designated shelters that are built to withstand severe weather conditions.'
        }
      ]
    }
  ];

  const adaptivePaths = [
    { id: 1, title: 'Beginner Pathway', modules: ['fire', 'earthquake'], difficulty: 'Easy', duration: '50 min' },
    { id: 2, title: 'Intermediate Pathway', modules: ['flood', 'earthquake', 'fire'], difficulty: 'Medium', duration: '75 min' },
    { id: 3, title: 'Advanced Pathway', modules: ['cyclone', 'flood', 'earthquake'], difficulty: 'Hard', duration: '90 min' }
  ];

  const recentQuizzes = [
    { id: 1, title: 'Earthquake Basics Quiz', score: 85, completed: true, badge: 'First Timer' },
    { id: 2, title: 'Fire Safety Challenge', score: 92, completed: true, badge: 'Safety Star' },
    { id: 3, title: 'Flood Response Test', score: 0, completed: false, badge: 'Pending' }
  ];

  if (selectedModule) {
    const module = modules.find(m => m.id === selectedModule);
    if (!module) return null;

    const scenario = module.scenarios[currentScenario];
    const Icon = module.icon;

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="outline" onClick={() => setSelectedModule(null)}>
            ← Back to Modules
          </Button>
          <Badge variant="outline">{module.difficulty}</Badge>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className={`p-3 rounded-lg bg-${module.color}-100`}>
                <Icon className={`h-6 w-6 text-${module.color}-600`} />
              </div>
              <div>
                <CardTitle>{module.title}</CardTitle>
                <CardDescription>{module.description}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <div className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-lg mb-4">Interactive Scenario</h3>
                  <div className="bg-white rounded-lg p-4 border">
                    <h4 className="mb-3">{scenario.title}</h4>
                    <p className="text-gray-600 mb-4">{scenario.description}</p>
                    
                    <div className="space-y-3">
                      {scenario.options.map((option, index) => (
                        <button
                          key={index}
                          className="w-full text-left p-3 border rounded-lg hover:bg-blue-50 hover:border-blue-300 transition-colors"
                          onClick={() => {
                            // Simulate quiz interaction
                            alert(index === scenario.correct ? 
                              `Correct! ${scenario.explanation}` : 
                              `Incorrect. ${scenario.explanation}`
                            );
                          }}
                        >
                          <span className="font-medium mr-2">{String.fromCharCode(65 + index)}.</span>
                          {option}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Module Progress</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Lessons</span>
                          <span>5/{module.lessons}</span>
                        </div>
                        <Progress value={62} />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Scenarios</span>
                          <span>1/{module.scenarios.length}</span>
                        </div>
                        <Progress value={100} />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Overall</span>
                          <span>68%</span>
                        </div>
                        <Progress value={68} />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Quick Stats</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Duration:</span>
                        <span>{module.duration}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Enrolled:</span>
                        <span>{module.enrolled} students</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Completion Rate:</span>
                        <span>{module.completionRate}%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Button className="w-full">
                  Continue Learning
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl mb-4">Interactive Learning Modules</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Learn disaster preparedness through engaging, interactive content tailored to your skill level. 
          Complete scenarios, earn badges, and track your progress.
        </p>
      </div>

      <Tabs defaultValue="modules" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="modules">All Modules</TabsTrigger>
          <TabsTrigger value="paths">Learning Paths</TabsTrigger>
          <TabsTrigger value="quizzes">Quizzes</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
        </TabsList>

        <TabsContent value="modules" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {modules.map((module) => {
              const Icon = module.icon;
              return (
                <Card key={module.id} className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedModule(module.id)}>
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className={`p-3 rounded-lg bg-${module.color}-100`}>
                        <Icon className={`h-6 w-6 text-${module.color}-600`} />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="flex items-center justify-between">
                          {module.title}
                          <Badge variant="outline">{module.difficulty}</Badge>
                        </CardTitle>
                        <CardDescription>{module.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{module.duration}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <BookOpen className="h-4 w-4" />
                          <span>{module.lessons} lessons</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Users className="h-4 w-4" />
                          <span>{module.enrolled}</span>
                        </span>
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Completion Rate</span>
                          <span>{module.completionRate}%</span>
                        </div>
                        <Progress value={module.completionRate} />
                      </div>

                      <Button className="w-full">
                        <Play className="h-4 w-4 mr-2" />
                        Start Learning
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="paths" className="space-y-6">
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl mb-2">Adaptive Learning Paths</h3>
              <p className="text-gray-600">Personalized learning journeys based on your skill level and interests</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {adaptivePaths.map((path) => (
                <Card key={path.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {path.title}
                      <Badge variant={
                        path.difficulty === 'Easy' ? 'default' : 
                        path.difficulty === 'Medium' ? 'secondary' : 'destructive'
                      }>
                        {path.difficulty}
                      </Badge>
                    </CardTitle>
                    <CardDescription>
                      {path.modules.length} modules • {path.duration}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        {path.modules.map((moduleId) => {
                          const module = modules.find(m => m.id === moduleId);
                          if (!module) return null;
                          const Icon = module.icon;
                          return (
                            <div key={moduleId} className="flex items-center space-x-2 text-sm">
                              <Icon className={`h-4 w-4 text-${module.color}-600`} />
                              <span>{module.title}</span>
                            </div>
                          );
                        })}
                      </div>
                      <Button className="w-full">
                        Start Path
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="quizzes" className="space-y-6">
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl mb-2">Knowledge Testing</h3>
              <p className="text-gray-600">Test your understanding with interactive quizzes and challenges</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentQuizzes.map((quiz) => (
                <Card key={quiz.id}>
                  <CardHeader>
                    <CardTitle className="text-base">{quiz.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {quiz.completed ? (
                        <div className="text-center">
                          <div className="text-3xl text-green-600 mb-2">{quiz.score}%</div>
                          <Badge variant="outline" className="text-green-600">
                            {quiz.badge}
                          </Badge>
                        </div>
                      ) : (
                        <div className="text-center">
                          <Clock className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                          <Badge variant="outline">Not Started</Badge>
                        </div>
                      )}
                      
                      <Button variant={quiz.completed ? "outline" : "default"} className="w-full">
                        {quiz.completed ? "Retake Quiz" : "Start Quiz"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Quick Assessment</CardTitle>
                <CardDescription>Test your overall disaster preparedness knowledge</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="mb-2">Take a comprehensive assessment covering all disaster types</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span>• 20 questions</span>
                      <span>• 15 minutes</span>
                      <span>• Adaptive difficulty</span>
                    </div>
                  </div>
                  <Button>
                    <Target className="h-4 w-4 mr-2" />
                    Start Assessment
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl mb-2">Achievements & Badges</h3>
              <p className="text-gray-600">Track your progress and earn recognition for your learning</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="p-3 bg-yellow-100 rounded-full w-fit mx-auto mb-3">
                    <Award className="h-8 w-8 text-yellow-600" />
                  </div>
                  <h4 className="mb-2">First Module Complete</h4>
                  <Badge className="bg-yellow-100 text-yellow-800">Earned</Badge>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="p-6">
                  <div className="p-3 bg-blue-100 rounded-full w-fit mx-auto mb-3">
                    <Target className="h-8 w-8 text-blue-600" />
                  </div>
                  <h4 className="mb-2">Quiz Master</h4>
                  <Badge className="bg-blue-100 text-blue-800">Earned</Badge>
                </CardContent>
              </Card>

              <Card className="text-center opacity-50">
                <CardContent className="p-6">
                  <div className="p-3 bg-gray-100 rounded-full w-fit mx-auto mb-3">
                    <Trophy className="h-8 w-8 text-gray-400" />
                  </div>
                  <h4 className="mb-2">All Modules Complete</h4>
                  <Badge variant="outline">Locked</Badge>
                </CardContent>
              </Card>

              <Card className="text-center opacity-50">
                <CardContent className="p-6">
                  <div className="p-3 bg-gray-100 rounded-full w-fit mx-auto mb-3">
                    <Star className="h-8 w-8 text-gray-400" />
                  </div>
                  <h4 className="mb-2">Perfect Score</h4>
                  <Badge variant="outline">Locked</Badge>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Achievement Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Modules Completed</span>
                      <span>2/4</span>
                    </div>
                    <Progress value={50} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Perfect Quiz Scores</span>
                      <span>1/5</span>
                    </div>
                    <Progress value={20} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Scenarios Completed</span>
                      <span>8/12</span>
                    </div>
                    <Progress value={67} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
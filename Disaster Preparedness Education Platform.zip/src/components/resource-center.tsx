import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  FileText, 
  Download, 
  MapPin, 
  Phone, 
  Shield, 
  Package, 
  Book,
  Globe,
  Printer,
  Smartphone,
  Wifi,
  WifiOff,
  CheckCircle,
  AlertTriangle,
  Heart,
  Home,
  Car,
  Briefcase
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ResourceCenterProps {
  userType: 'student' | 'teacher' | 'community' | null;
}

export function ResourceCenter({ userType }: ResourceCenterProps) {
  // Mock data for preparedness kits
  const preparednessKits = [
    {
      id: 'home-basic',
      title: 'Basic Home Emergency Kit',
      description: 'Essential supplies for a family of 4 for 72 hours',
      category: 'home',
      difficulty: 'Beginner',
      cost: '$150-200',
      items: [
        { name: 'Water (1 gallon per person per day)', quantity: '12 gallons', priority: 'high', checked: false },
        { name: 'Non-perishable food', quantity: '3-day supply', priority: 'high', checked: false },
        { name: 'Battery-powered radio', quantity: '1', priority: 'high', checked: false },
        { name: 'Flashlight', quantity: '1 per person', priority: 'high', checked: false },
        { name: 'First aid kit', quantity: '1 comprehensive', priority: 'high', checked: false },
        { name: 'Extra batteries', quantity: 'Various sizes', priority: 'medium', checked: false },
        { name: 'Whistle for signaling help', quantity: '1 per person', priority: 'medium', checked: false },
        { name: 'Dust masks', quantity: '2 per person', priority: 'medium', checked: false }
      ],
      tips: [
        'Store in waterproof containers',
        'Check expiration dates every 6 months',
        'Keep kit in easily accessible location',
        'Include copies of important documents'
      ]
    },
    {
      id: 'school-classroom',
      title: 'Classroom Emergency Kit',
      description: 'Supplies for teachers to manage classroom emergencies',
      category: 'school',
      difficulty: 'Intermediate',
      cost: '$75-100',
      items: [
        { name: 'Emergency contact list', quantity: '1 updated copy', priority: 'high', checked: false },
        { name: 'First aid supplies', quantity: '1 kit', priority: 'high', checked: false },
        { name: 'Emergency whistle', quantity: '1', priority: 'high', checked: false },
        { name: 'Flashlight with extra batteries', quantity: '1', priority: 'high', checked: false },
        { name: 'Emergency procedures guide', quantity: '1', priority: 'high', checked: false },
        { name: 'Plastic sheeting and duct tape', quantity: '1 roll each', priority: 'medium', checked: false },
        { name: 'Hand sanitizer', quantity: '2 bottles', priority: 'medium', checked: false },
        { name: 'Emergency blankets', quantity: '5', priority: 'low', checked: false }
      ],
      tips: [
        'Review contents with students monthly',
        'Practice using equipment regularly',
        'Coordinate with school emergency plan',
        'Keep student medical information updated'
      ]
    },
    {
      id: 'car-travel',
      title: 'Vehicle Emergency Kit',
      description: 'Mobile emergency supplies for travelers',
      category: 'vehicle',
      difficulty: 'Beginner',
      cost: '$100-150',
      items: [
        { name: 'Jumper cables', quantity: '1 set', priority: 'high', checked: false },
        { name: 'Tire repair kit and pump', quantity: '1', priority: 'high', checked: false },
        { name: 'Emergency flares or reflectors', quantity: '6', priority: 'high', checked: false },
        { name: 'Multi-tool or Swiss Army knife', quantity: '1', priority: 'medium', checked: false },
        { name: 'Fire extinguisher', quantity: '1 small', priority: 'medium', checked: false },
        { name: 'Emergency blankets', quantity: '2', priority: 'medium', checked: false },
        { name: 'Water and snacks', quantity: '2-day supply', priority: 'medium', checked: false },
        { name: 'Phone charger (12V adapter)', quantity: '1', priority: 'low', checked: false }
      ],
      tips: [
        'Check tire pressure and spare regularly',
        'Keep gas tank at least half full',
        'Learn basic car maintenance',
        'Share travel plans with family/friends'
      ]
    },
    {
      id: 'workplace',
      title: 'Office Emergency Kit',
      description: 'Workplace preparedness for office environments',
      category: 'office',
      difficulty: 'Intermediate',
      cost: '$50-75',
      items: [
        { name: 'Comfortable walking shoes', quantity: '1 pair', priority: 'high', checked: false },
        { name: 'Emergency contact information', quantity: '1 card', priority: 'high', checked: false },
        { name: 'Medications (if needed)', quantity: '3-day supply', priority: 'high', checked: false },
        { name: 'Small flashlight', quantity: '1', priority: 'medium', checked: false },
        { name: 'Energy bars', quantity: '3-day supply', priority: 'medium', checked: false },
        { name: 'Water bottles', quantity: '3', priority: 'medium', checked: false },
        { name: 'Small first aid kit', quantity: '1', priority: 'medium', checked: false },
        { name: 'Emergency blanket', quantity: '1', priority: 'low', checked: false }
      ],
      tips: [
        'Know multiple evacuation routes',
        'Participate in office drills',
        'Keep kit in desk or locker',
        'Coordinate with workplace emergency plan'
      ]
    }
  ];

  const emergencyContacts = [
    {
      category: 'Emergency Services',
      contacts: [
        { name: 'Emergency (Police, Fire, Medical)', number: '911', type: 'emergency', available: '24/7' },
        { name: 'Poison Control Center', number: '1-800-222-1222', type: 'emergency', available: '24/7' },
        { name: 'National Suicide Prevention Lifeline', number: '988', type: 'emergency', available: '24/7' }
      ]
    },
    {
      category: 'Disaster Information',
      contacts: [
        { name: 'FEMA Disaster Assistance', number: '1-800-621-3362', type: 'disaster', available: '24/7' },
        { name: 'American Red Cross', number: '1-800-733-2767', type: 'disaster', available: '24/7' },
        { name: 'National Weather Service', number: '1-800-985-9770', type: 'weather', available: '24/7' }
      ]
    },
    {
      category: 'Local Services',
      contacts: [
        { name: 'City Emergency Management', number: '(555) 123-4567', type: 'local', available: 'Business hours' },
        { name: 'Local Hospital', number: '(555) 234-5678', type: 'medical', available: '24/7' },
        { name: 'Utilities Emergency Line', number: '(555) 345-6789', type: 'utility', available: '24/7' },
        { name: 'School District Emergency', number: '(555) 456-7890', type: 'school', available: 'School hours' }
      ]
    }
  ];

  const educationalResources = [
    {
      id: 1,
      title: 'Family Emergency Planning Guide',
      description: 'Step-by-step guide to creating a comprehensive family emergency plan',
      type: 'PDF Guide',
      pages: 24,
      language: ['English', 'Spanish'],
      topics: ['Communication plans', 'Evacuation routes', 'Meeting points', 'Important documents'],
      downloadSize: '2.3 MB'
    },
    {
      id: 2,
      title: 'Earthquake Safety Poster Set',
      description: 'Colorful educational posters for classrooms and community centers',
      type: 'Poster Set',
      pages: 6,
      language: ['English', 'Spanish', 'Mandarin'],
      topics: ['Drop, Cover, Hold On', 'After the shaking', 'Preparation tips', 'Emergency kit'],
      downloadSize: '8.1 MB'
    },
    {
      id: 3,
      title: 'Flood Safety Interactive Workbook',
      description: 'Activities and exercises for students to learn flood preparedness',
      type: 'Interactive PDF',
      pages: 16,
      language: ['English'],
      topics: ['Flood risks', 'Evacuation planning', 'Water safety', 'Recovery basics'],
      downloadSize: '4.7 MB'
    },
    {
      id: 4,
      title: 'Fire Safety Home Checklist',
      description: 'Printable checklist for home fire safety assessment',
      type: 'Checklist',
      pages: 4,
      language: ['English', 'Spanish'],
      topics: ['Smoke detectors', 'Escape routes', 'Fire extinguishers', 'Prevention tips'],
      downloadSize: '1.2 MB'
    }
  ];

  const nearbyFacilities = [
    {
      name: 'Central Community Hospital',
      type: 'Hospital',
      address: '123 Main Street',
      distance: '0.8 miles',
      phone: '(555) 123-4567',
      services: ['Emergency Room', 'Trauma Center', 'Helicopter Landing'],
      available: true
    },
    {
      name: 'Fire Station #3',
      type: 'Fire Station',
      address: '456 Oak Avenue',
      distance: '1.2 miles',
      phone: '(555) 234-5678',
      services: ['Fire Response', 'EMS', 'Rescue Operations', 'Emergency Shelter'],
      available: true
    },
    {
      name: 'Lincoln High School',
      type: 'Emergency Shelter',
      address: '789 School Drive',
      distance: '0.5 miles',
      phone: '(555) 345-6789',
      services: ['Mass Shelter', 'Food Distribution', 'Family Reunification'],
      available: false
    },
    {
      name: 'Community Center',
      type: 'Emergency Shelter',
      address: '321 Center Street',
      distance: '0.7 miles',
      phone: '(555) 456-7890',
      services: ['Emergency Shelter', 'Cooling Center', 'Information Hub'],
      available: true
    },
    {
      name: 'Police Station',
      type: 'Police Station',
      address: '654 Safety Boulevard',
      distance: '1.0 miles',
      phone: '(555) 567-8901',
      services: ['Emergency Response', 'Traffic Control', 'Evacuation Assistance'],
      available: true
    }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl mb-4">Resource Center</h2>
        <p className="text-gray-600 max-w-3xl mx-auto">
          Access comprehensive emergency preparedness resources, download guides, find local emergency contacts, 
          and discover nearby help centers. Everything you need to stay prepared and informed.
        </p>
      </div>

      <Tabs defaultValue="kits" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="kits">Preparedness Kits</TabsTrigger>
          <TabsTrigger value="contacts">Emergency Contacts</TabsTrigger>
          <TabsTrigger value="facilities">Nearby Facilities</TabsTrigger>
          <TabsTrigger value="resources">Educational Resources</TabsTrigger>
          <TabsTrigger value="offline">Offline Access</TabsTrigger>
        </TabsList>

        <TabsContent value="kits" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Emergency Preparedness Kits</h3>
            <p className="text-gray-600">Interactive guides to help you build comprehensive emergency kits for different situations</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {preparednessKits.map((kit) => (
              <Card key={kit.id} className="overflow-hidden">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      kit.category === 'home' ? 'bg-blue-100' :
                      kit.category === 'school' ? 'bg-green-100' :
                      kit.category === 'vehicle' ? 'bg-orange-100' :
                      'bg-purple-100'
                    }`}>
                      {kit.category === 'home' ? <Home className={`h-5 w-5 text-blue-600`} /> :
                       kit.category === 'school' ? <Book className={`h-5 w-5 text-green-600`} /> :
                       kit.category === 'vehicle' ? <Car className={`h-5 w-5 text-orange-600`} /> :
                       <Briefcase className={`h-5 w-5 text-purple-600`} />}
                    </div>
                    <div className="flex-1">
                      <CardTitle className="flex items-center justify-between">
                        {kit.title}
                        <Badge variant="outline">{kit.difficulty}</Badge>
                      </CardTitle>
                      <CardDescription>{kit.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center space-x-1">
                      <Package className="h-4 w-4 text-gray-400" />
                      <span>{kit.items.length} items</span>
                    </span>
                    <span className="text-gray-600">Est. Cost: {kit.cost}</span>
                  </div>

                  <div>
                    <h4 className="mb-3 flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Essential Items</span>
                    </h4>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {kit.items.slice(0, 6).map((item, index) => (
                        <div key={index} className="flex items-start space-x-3 p-2 hover:bg-gray-50 rounded">
                          <div className={`w-3 h-3 rounded border-2 mt-1 ${
                            item.priority === 'high' ? 'border-red-500' :
                            item.priority === 'medium' ? 'border-orange-500' :
                            'border-gray-300'
                          }`}></div>
                          <div className="flex-1">
                            <span className="text-sm">{item.name}</span>
                            <p className="text-xs text-gray-500">{item.quantity}</p>
                          </div>
                          <Badge variant="outline" className={`text-xs ${
                            item.priority === 'high' ? 'border-red-300 text-red-700' :
                            item.priority === 'medium' ? 'border-orange-300 text-orange-700' :
                            'border-gray-300 text-gray-700'
                          }`}>
                            {item.priority}
                          </Badge>
                        </div>
                      ))}
                      {kit.items.length > 6 && (
                        <p className="text-xs text-gray-500 text-center">+{kit.items.length - 6} more items</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="mb-2 flex items-center space-x-2">
                      <AlertTriangle className="h-4 w-4 text-orange-500" />
                      <span>Important Tips</span>
                    </h4>
                    <ul className="space-y-1">
                      {kit.tips.slice(0, 2).map((tip, index) => (
                        <li key={index} className="text-sm text-gray-600 flex items-start space-x-2">
                          <span className="text-orange-500 mt-1">•</span>
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex space-x-2">
                    <Button className="flex-1">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Start Building Kit
                    </Button>
                    <Button variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Download Guide
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="contacts" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Emergency Contact Directory</h3>
            <p className="text-gray-600">Important phone numbers for emergency situations and disaster assistance</p>
          </div>

          <div className="space-y-6">
            {emergencyContacts.map((category, categoryIndex) => (
              <Card key={categoryIndex}>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Phone className="h-5 w-5 text-blue-500" />
                    <span>{category.category}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {category.contacts.map((contact, contactIndex) => (
                      <div key={contactIndex} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <h4 className="mb-1">{contact.name}</h4>
                          <p className="text-lg text-blue-600">{contact.number}</p>
                          <p className="text-xs text-gray-500">{contact.available}</p>
                        </div>
                        <Badge variant={
                          contact.type === 'emergency' ? 'destructive' :
                          contact.type === 'disaster' ? 'default' :
                          'outline'
                        }>
                          {contact.type}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-gradient-to-r from-red-50 to-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                <span>Emergency Calling Tips</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="mb-3">When calling 911:</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Stay calm and speak clearly</li>
                    <li>• Give your exact location</li>
                    <li>• Describe the emergency</li>
                    <li>• Follow the dispatcher's instructions</li>
                    <li>• Don't hang up until told to do so</li>
                  </ul>
                </div>
                <div>
                  <h4 className="mb-3">Have ready:</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Your location address</li>
                    <li>• Nature of emergency</li>
                    <li>• Number of people involved</li>
                    <li>• Any medical conditions</li>
                    <li>• Your callback number</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="facilities" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Nearby Emergency Facilities</h3>
            <p className="text-gray-600">Locate hospitals, shelters, fire stations, and other emergency services in your area</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {nearbyFacilities.map((facility, index) => (
              <Card key={index} className={`${!facility.available ? 'opacity-75' : ''}`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${
                        facility.type === 'Hospital' ? 'bg-red-100' :
                        facility.type === 'Fire Station' ? 'bg-orange-100' :
                        facility.type === 'Police Station' ? 'bg-blue-100' :
                        'bg-green-100'
                      }`}>
                        {facility.type === 'Hospital' ? <Heart className="h-5 w-5 text-red-600" /> :
                         facility.type === 'Fire Station' ? <Shield className="h-5 w-5 text-orange-600" /> :
                         facility.type === 'Police Station' ? <Shield className="h-5 w-5 text-blue-600" /> :
                         <Home className="h-5 w-5 text-green-600" />}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{facility.name}</CardTitle>
                        <CardDescription>{facility.type}</CardDescription>
                      </div>
                    </div>
                    <Badge variant={facility.available ? 'default' : 'secondary'}>
                      {facility.available ? 'Available' : 'Limited'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span>{facility.address}</span>
                    </div>
                    <span className="text-blue-600">{facility.distance}</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <span className="text-sm">{facility.phone}</span>
                  </div>

                  <div>
                    <h4 className="text-sm mb-2 text-gray-600">Services Available:</h4>
                    <div className="flex flex-wrap gap-1">
                      {facility.services.map((service, serviceIndex) => (
                        <Badge key={serviceIndex} variant="outline" className="text-xs">
                          {service}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <MapPin className="h-4 w-4 mr-2" />
                      Get Directions
                    </Button>
                    <Button variant="outline" size="sm">
                      <Phone className="h-4 w-4 mr-2" />
                      Call
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-blue-500" />
                <span>Interactive Emergency Map</span>
              </CardTitle>
              <CardDescription>View all emergency facilities and evacuation routes on an interactive map</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-100 rounded-lg p-8 text-center">
                <Globe className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="mb-2">Interactive Map View</h3>
                <p className="text-gray-600 mb-4">
                  Click to open a detailed map showing all emergency facilities, evacuation routes, and safe zones in your area.
                </p>
                <Button>
                  <MapPin className="h-4 w-4 mr-2" />
                  Open Emergency Map
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Educational Resources</h3>
            <p className="text-gray-600">Download guides, posters, checklists, and educational materials for disaster preparedness</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {educationalResources.map((resource) => (
              <Card key={resource.id}>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <FileText className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-lg">{resource.title}</CardTitle>
                      <CardDescription>{resource.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Type:</span>
                      <p className="font-medium">{resource.type}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Pages:</span>
                      <p className="font-medium">{resource.pages}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Size:</span>
                      <p className="font-medium">{resource.downloadSize}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Languages:</span>
                      <p className="font-medium">{resource.language.join(', ')}</p>
                    </div>
                  </div>

                  <div>
                    <span className="text-sm text-gray-600 mb-2 block">Topics Covered:</span>
                    <div className="flex flex-wrap gap-1">
                      {resource.topics.map((topic, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {topic}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button className="flex-1">
                      <Download className="h-4 w-4 mr-2" />
                      Download PDF
                    </Button>
                    <Button variant="outline">
                      <Printer className="h-4 w-4 mr-2" />
                      Print Version
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {userType === 'teacher' && (
            <Card className="bg-gradient-to-r from-green-50 to-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Book className="h-5 w-5 text-green-500" />
                  <span>Teacher Resources</span>
                </CardTitle>
                <CardDescription>Additional materials specifically designed for educators</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4">
                    <FileText className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                    <h4 className="mb-2">Lesson Plans</h4>
                    <p className="text-sm text-gray-600 mb-3">Ready-to-use lesson plans for all grade levels</p>
                    <Button variant="outline" size="sm">Download</Button>
                  </div>
                  <div className="text-center p-4">
                    <Globe className="h-8 w-8 text-green-500 mx-auto mb-2" />
                    <h4 className="mb-2">Interactive Activities</h4>
                    <p className="text-sm text-gray-600 mb-3">Engaging classroom activities and games</p>
                    <Button variant="outline" size="sm">Download</Button>
                  </div>
                  <div className="text-center p-4">
                    <CheckCircle className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                    <h4 className="mb-2">Assessment Tools</h4>
                    <p className="text-sm text-gray-600 mb-3">Quizzes and evaluation materials</p>
                    <Button variant="outline" size="sm">Download</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="offline" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Offline & Low-Tech Access</h3>
            <p className="text-gray-600">Access critical information even without internet connectivity or during emergencies</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <WifiOff className="h-5 w-5 text-red-500" />
                  <span>Offline Content Packs</span>
                </CardTitle>
                <CardDescription>Download essential information for offline access</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="mb-1">Emergency Response Guide</h4>
                      <p className="text-sm text-gray-600">Complete offline manual - 45 MB</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="mb-1">Local Emergency Maps</h4>
                      <p className="text-sm text-gray-600">Printable evacuation routes - 12 MB</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="mb-1">First Aid Quick Reference</h4>
                      <p className="text-sm text-gray-600">Essential medical procedures - 8 MB</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Smartphone className="h-5 w-5 text-blue-500" />
                  <span>SMS Alert System</span>
                </CardTitle>
                <CardDescription>Receive emergency alerts via text message</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">
                  Sign up to receive critical emergency alerts and updates via SMS, even when internet 
                  connectivity is limited or unavailable.
                </p>
                
                <div className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="mb-1">Weather Alerts</h4>
                    <p className="text-xs text-gray-600">Severe weather warnings and updates</p>
                  </div>
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <h4 className="mb-1">Emergency Notifications</h4>
                    <p className="text-xs text-gray-600">Immediate threats and evacuation orders</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <h4 className="mb-1">Safety Information</h4>
                    <p className="text-xs text-gray-600">Recovery updates and safety tips</p>
                  </div>
                </div>

                <Button className="w-full">
                  <Smartphone className="h-4 w-4 mr-2" />
                  Subscribe to SMS Alerts
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Printer className="h-5 w-5 text-gray-600" />
                <span>Printable Emergency Resources</span>
              </CardTitle>
              <CardDescription>Physical backups for when digital systems fail</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="p-3 bg-red-100 rounded-lg mb-3 w-fit mx-auto">
                    <MapPin className="h-8 w-8 text-red-600" />
                  </div>
                  <h4 className="mb-2">Emergency Contact Cards</h4>
                  <p className="text-sm text-gray-600 mb-3">Wallet-sized cards with essential numbers</p>
                  <Button variant="outline" size="sm">
                    <Printer className="h-4 w-4 mr-2" />
                    Print Cards
                  </Button>
                </div>
                <div className="text-center">
                  <div className="p-3 bg-blue-100 rounded-lg mb-3 w-fit mx-auto">
                    <Home className="h-8 w-8 text-blue-600" />
                  </div>
                  <h4 className="mb-2">Family Emergency Plan</h4>
                  <p className="text-sm text-gray-600 mb-3">Fill-in-the-blank planning template</p>
                  <Button variant="outline" size="sm">
                    <Printer className="h-4 w-4 mr-2" />
                    Print Template
                  </Button>
                </div>
                <div className="text-center">
                  <div className="p-3 bg-green-100 rounded-lg mb-3 w-fit mx-auto">
                    <CheckCircle className="h-8 w-8 text-green-600" />
                  </div>
                  <h4 className="mb-2">Preparedness Checklists</h4>
                  <p className="text-sm text-gray-600 mb-3">Step-by-step preparation guides</p>
                  <Button variant="outline" size="sm">
                    <Printer className="h-4 w-4 mr-2" />
                    Print Lists
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-50 to-red-50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-orange-500" />
                <span>Emergency Communication Plan</span>
              </CardTitle>
              <CardDescription>Stay connected when technology fails</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="mb-3">Low-Tech Communication Methods</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Battery-powered or hand-crank radio</li>
                    <li>• Whistle for signaling help</li>
                    <li>• Mirrors for visual signals</li>
                    <li>• Written messages and notes</li>
                    <li>• Neighbors and community networks</li>
                  </ul>
                </div>
                <div>
                  <h4 className="mb-3">Backup Power Solutions</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Portable phone chargers/power banks</li>
                    <li>• Solar phone chargers</li>
                    <li>• Car chargers and adapters</li>
                    <li>• Extra batteries for devices</li>
                    <li>• Hand-crank emergency radios</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
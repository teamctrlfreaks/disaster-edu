import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Users, 
  Home, 
  Heart, 
  Shield, 
  AlertTriangle, 
  MapPin, 
  Phone,
  FileText,
  MessageCircle,
  Calendar,
  CheckCircle,
  Star,
  TrendingUp
} from 'lucide-react';

export function CommunityDashboard() {
  // Mock community data
  const communityData = {
    name: "The Johnson Family",
    children: 2,
    preparednessScore: 72,
    emergencyContacts: 8,
    completedChecklists: 6
  };

  const familyMembers = [
    { name: "Emma Johnson", grade: "8th Grade", score: 85, status: "Active" },
    { name: "Michael Johnson", grade: "6th Grade", score: 78, status: "Needs Practice" }
  ];

  const preparednessChecklist = [
    { id: 1, item: "Emergency Kit Assembled", completed: true, priority: "high" },
    { id: 2, item: "Family Emergency Plan", completed: true, priority: "high" },
    { id: 3, item: "Emergency Contacts Updated", completed: true, priority: "high" },
    { id: 4, item: "Important Documents Secured", completed: true, priority: "medium" },
    { id: 5, item: "Water Storage (3-day supply)", completed: true, priority: "high" },
    { id: 6, item: "First Aid Kit Stocked", completed: true, priority: "medium" },
    { id: 7, item: "Backup Power Source", completed: false, priority: "medium" },
    { id: 8, item: "Communication Plan", completed: false, priority: "high" },
    { id: 9, item: "Home Evacuation Route", completed: false, priority: "high" }
  ];

  const communityEvents = [
    { id: 1, title: "Emergency Response Training", date: "This Saturday", location: "Community Center", participants: 45 },
    { id: 2, title: "First Aid Workshop", date: "Next Week", location: "Lincoln High School", participants: 32 },
    { id: 3, title: "Neighborhood Safety Meeting", date: "Nov 20", location: "Fire Station", participants: 28 }
  ];

  const emergencyContacts = [
    { type: "Police", number: "911", category: "emergency" },
    { type: "Fire Department", number: "911", category: "emergency" },
    { type: "Hospital", number: "(555) 123-4567", category: "medical" },
    { type: "School (Lincoln High)", number: "(555) 234-5678", category: "school" },
    { type: "Neighbor (Smith Family)", number: "(555) 345-6789", category: "neighbor" }
  ];

  const completedItems = preparednessChecklist.filter(item => item.completed).length;
  const completionPercentage = Math.round((completedItems / preparednessChecklist.length) * 100);

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl mb-2">Welcome, {communityData.name}!</h2>
            <p className="text-purple-100">Keep your family safe and prepared for emergencies</p>
            <div className="flex items-center space-x-4 mt-4">
              <Badge variant="secondary" className="text-white bg-white/20">
                {communityData.children} Children
              </Badge>
              <Badge variant="secondary" className="text-white bg-white/20">
                {communityData.emergencyContacts} Emergency Contacts
              </Badge>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl mb-1">{communityData.preparednessScore}%</div>
            <div className="text-purple-100">Family Preparedness</div>
            <Badge variant="secondary" className="mt-2 text-white bg-white/20">
              {completedItems}/{preparednessChecklist.length} Complete
            </Badge>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Home className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Home Preparedness</p>
                <p className="text-2xl">{completionPercentage}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Users className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Children Progress</p>
                <p className="text-2xl">{Math.round((familyMembers.reduce((sum, member) => sum + member.score, 0) / familyMembers.length))}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Heart className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Community Events</p>
                <p className="text-2xl">{communityEvents.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Shield className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Safety Score</p>
                <p className="text-2xl">A-</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Family Progress */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>Family Progress</span>
            </CardTitle>
            <CardDescription>Track your children's disaster preparedness learning</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {familyMembers.map((member, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="mb-1">{member.name}</h4>
                    <p className="text-sm text-gray-600">{member.grade}</p>
                  </div>
                  <Badge variant={member.status === "Active" ? "default" : "outline"}>
                    {member.status}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Preparedness Score</span>
                    <span>{member.score}%</span>
                  </div>
                  <Progress value={member.score} />
                </div>
                <div className="flex space-x-2 mt-3">
                  <Button variant="outline" size="sm">View Details</Button>
                  <Button size="sm">Send Encouragement</Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Family Preparedness Checklist */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5" />
              <span>Family Preparedness Checklist</span>
            </CardTitle>
            <CardDescription>Essential steps to keep your family safe</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {preparednessChecklist.map((item) => (
                <div key={item.id} className={`flex items-center justify-between p-3 rounded-lg ${
                  item.completed ? 'bg-green-50 border border-green-200' : 'bg-gray-50 border border-gray-200'
                }`}>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className={`h-5 w-5 ${
                      item.completed ? 'text-green-600' : 'text-gray-400'
                    }`} />
                    <span className={`text-sm ${item.completed ? 'text-green-800' : 'text-gray-700'}`}>
                      {item.item}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={
                      item.priority === 'high' ? 'destructive' : 
                      item.priority === 'medium' ? 'default' : 'outline'
                    } className="text-xs">
                      {item.priority}
                    </Badge>
                    {!item.completed && (
                      <Button variant="outline" size="sm">Complete</Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex justify-between text-sm mb-2">
                <span>Overall Progress</span>
                <span>{completedItems}/{preparednessChecklist.length}</span>
              </div>
              <Progress value={completionPercentage} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Community Events */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5" />
            <span>Upcoming Community Events</span>
          </CardTitle>
          <CardDescription>Join local disaster preparedness activities</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {communityEvents.map((event) => (
            <div key={event.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Calendar className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h4 className="mb-1">{event.title}</h4>
                  <p className="text-sm text-gray-600">{event.date} • {event.location}</p>
                  <Badge variant="outline" className="mt-1">{event.participants} registered</Badge>
                </div>
              </div>
              <div className="space-x-2">
                <Button variant="outline" size="sm">Learn More</Button>
                <Button size="sm">Register</Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Emergency Resources */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Phone className="h-5 w-5" />
              <span>Emergency Contacts</span>
            </CardTitle>
            <CardDescription>Important numbers for your family</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {emergencyContacts.map((contact, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="mb-1">{contact.type}</h4>
                  <p className="text-sm text-gray-600">{contact.number}</p>
                </div>
                <Badge variant="outline" className="capitalize">{contact.category}</Badge>
              </div>
            ))}
            <Button className="w-full mt-4">
              <Phone className="h-4 w-4 mr-2" />
              Add Contact
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MapPin className="h-5 w-5" />
              <span>Nearby Resources</span>
            </CardTitle>
            <CardDescription>Emergency facilities in your area</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 border rounded-lg">
              <h4 className="mb-1">Central Hospital</h4>
              <p className="text-sm text-gray-600">0.8 miles away • Emergency services</p>
            </div>
            <div className="p-3 border rounded-lg">
              <h4 className="mb-1">Fire Station #3</h4>
              <p className="text-sm text-gray-600">1.2 miles away • Evacuation shelter</p>
            </div>
            <div className="p-3 border rounded-lg">
              <h4 className="mb-1">Community Center</h4>
              <p className="text-sm text-gray-600">0.5 miles away • Emergency shelter</p>
            </div>
            <Button variant="outline" className="w-full mt-4">
              <MapPin className="h-4 w-4 mr-2" />
              View Map
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="p-3 bg-blue-100 rounded-full w-fit mx-auto mb-4">
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="mb-2">Family Emergency Plan</h3>
            <p className="text-sm text-gray-600 mb-4">Create or update your family's emergency response plan</p>
            <Button className="w-full">Create Plan</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="p-3 bg-green-100 rounded-full w-fit mx-auto mb-4">
              <MessageCircle className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="mb-2">Community Forum</h3>
            <p className="text-sm text-gray-600 mb-4">Connect with neighbors and share safety tips</p>
            <Button variant="outline" className="w-full">Join Discussion</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="p-3 bg-orange-100 rounded-full w-fit mx-auto mb-4">
              <Heart className="h-8 w-8 text-orange-600" />
            </div>
            <h3 className="mb-2">Volunteer</h3>
            <p className="text-sm text-gray-600 mb-4">Help your community with disaster preparedness</p>
            <Button variant="outline" className="w-full">Find Opportunities</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
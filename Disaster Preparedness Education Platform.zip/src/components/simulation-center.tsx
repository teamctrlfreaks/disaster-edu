import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Play, 
  Gamepad2, 
  Target, 
  Users, 
  Clock, 
  Star,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Zap,
  Trophy,
  Eye,
  Headphones,
  Monitor,
  Calendar,
  Map
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface SimulationCenterProps {
  userType: 'student' | 'teacher' | 'community' | null;
}

export function SimulationCenter({ userType }: SimulationCenterProps) {
  const [activeSimulation, setActiveSimulation] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(0);

  // Mock simulation data
  const virtualSimulations = [
    {
      id: 'earthquake-vr',
      title: 'Earthquake Response VR',
      description: 'Immersive virtual reality experience of earthquake response in a school setting',
      type: 'VR',
      difficulty: 'Intermediate',
      duration: '15 min',
      participants: 'Individual',
      technology: 'VR Headset Required',
      scenarios: ['Classroom', 'Playground', 'Laboratory'],
      objectives: [
        'Practice Drop, Cover, and Hold On',
        'Navigate evacuation routes safely',
        'Assist others during emergency',
        'Identify safe and unsafe locations'
      ],
      image: "https://images.unsplash.com/photo-1572996489045-96ed977a73b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
      available: true
    },
    {
      id: 'flood-ar',
      title: 'Flood Evacuation AR',
      description: 'Augmented reality simulation overlaying flood scenarios on real environments',
      type: 'AR',
      difficulty: 'Beginner',
      duration: '12 min',
      participants: 'Individual/Group',
      technology: 'Smartphone/Tablet',
      scenarios: ['Home Evacuation', 'Community Center', 'Urban Environment'],
      objectives: [
        'Plan evacuation routes',
        'Identify flood hazards',
        'Practice emergency communication',
        'Navigate to safe zones'
      ],
      image: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
      available: true
    },
    {
      id: 'fire-mixed',
      title: 'Fire Safety Mixed Reality',
      description: 'Combined VR and physical practice for comprehensive fire emergency response',
      type: 'Mixed Reality',
      difficulty: 'Advanced',
      duration: '20 min',
      participants: 'Groups of 4-6',
      technology: 'VR + Physical Props',
      scenarios: ['Kitchen Fire', 'Office Building', 'Chemical Lab'],
      objectives: [
        'Use fire extinguisher properly',
        'Execute evacuation procedures',
        'Practice smoke navigation',
        'Coordinate team response'
      ],
      image: "https://images.unsplash.com/photo-1614036417651-efe5912149d8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
      available: false
    },
    {
      id: 'cyclone-sim',
      title: 'Cyclone Preparedness Simulation',
      description: 'Desktop simulation for planning and decision-making during cyclone approach',
      type: 'Desktop Simulation',
      difficulty: 'Intermediate',
      duration: '25 min',
      participants: 'Individual',
      technology: 'Computer/Browser',
      scenarios: ['Coastal Community', 'Urban Area', 'Rural Settlement'],
      objectives: [
        'Make evacuation decisions',
        'Manage emergency supplies',
        'Coordinate community response',
        'Monitor weather updates'
      ],
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
      available: true
    }
  ];

  const hybridDrills = [
    {
      id: 'school-earthquake',
      title: 'School Earthquake Drill',
      description: 'Combined virtual training and physical practice for school-wide earthquake response',
      type: 'Hybrid',
      duration: '45 min',
      participants: '100-500 students',
      phases: [
        'Virtual briefing and instruction',
        'Practice scenarios on tablets',
        'Physical evacuation drill',
        'Debrief and assessment'
      ],
      nextSession: 'Today at 2:00 PM',
      enrolled: 245,
      maxCapacity: 300
    },
    {
      id: 'community-flood',
      title: 'Community Flood Response',
      description: 'Neighborhood-wide flood preparedness combining digital planning and real exercises',
      type: 'Hybrid',
      duration: '2 hours',
      participants: '50-200 residents',
      phases: [
        'Online flood risk assessment',
        'Virtual evacuation planning',
        'Physical route practice',
        'Community coordination exercise'
      ],
      nextSession: 'Saturday at 10:00 AM',
      enrolled: 67,
      maxCapacity: 150
    },
    {
      id: 'family-fire',
      title: 'Family Fire Safety',
      description: 'Home-based fire safety combining app-guided learning and family practice',
      type: 'Hybrid',
      duration: '30 min',
      participants: '2-8 family members',
      phases: [
        'App-based fire safety quiz',
        'Virtual home fire escape planning',
        'Physical evacuation practice',
        'Family meeting and plan review'
      ],
      nextSession: 'Available anytime',
      enrolled: 156,
      maxCapacity: 'Unlimited'
    }
  ];

  const drillResults = [
    { id: 1, drill: 'School Earthquake Drill', date: 'Yesterday', participants: 234, avgTime: '3:45', score: 87 },
    { id: 2, drill: 'Fire Evacuation Practice', date: '3 days ago', participants: 189, avgTime: '2:12', score: 92 },
    { id: 3, drill: 'Flood Response Exercise', date: '1 week ago', participants: 156, avgTime: '8:30', score: 76 }
  ];

  if (activeSimulation) {
    const simulation = virtualSimulations.find(s => s.id === activeSimulation);
    if (!simulation) return null;

    const steps = [
      'Equipment Setup',
      'Safety Briefing',
      'Scenario Introduction',
      'Interactive Practice',
      'Performance Review'
    ];

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="outline" onClick={() => setActiveSimulation(null)}>
            ← Back to Simulations
          </Button>
          <div className="flex items-center space-x-2">
            <Badge variant="outline">{simulation.type}</Badge>
            <Badge variant="outline">{simulation.difficulty}</Badge>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Eye className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <div>{simulation.title}</div>
                <CardDescription>{simulation.description}</CardDescription>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <div className="bg-gradient-to-br from-blue-900 to-purple-900 rounded-lg p-6 text-white relative overflow-hidden">
                  <div className="relative z-10">
                    <h3 className="text-xl mb-4">Simulation Progress</h3>
                    <div className="space-y-4">
                      {steps.map((step, index) => (
                        <div key={index} className={`flex items-center space-x-3 ${index <= currentStep ? 'opacity-100' : 'opacity-50'}`}>
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            index < currentStep ? 'bg-green-500' : 
                            index === currentStep ? 'bg-blue-500' : 'bg-gray-600'
                          }`}>
                            {index < currentStep ? (
                              <CheckCircle className="h-4 w-4" />
                            ) : (
                              <span className="text-sm">{index + 1}</span>
                            )}
                          </div>
                          <span>{step}</span>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-6">
                      <div className="flex justify-between text-sm mb-2">
                        <span>Overall Progress</span>
                        <span>{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
                      </div>
                      <Progress value={((currentStep + 1) / steps.length) * 100} className="bg-white/20" />
                    </div>

                    <div className="flex space-x-3 mt-6">
                      <Button 
                        variant="secondary" 
                        disabled={currentStep === 0}
                        onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                      >
                        Previous Step
                      </Button>
                      <Button 
                        onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
                        disabled={currentStep === steps.length - 1}
                      >
                        {currentStep === steps.length - 1 ? 'Complete' : 'Next Step'}
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                </div>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Simulation Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span>Duration:</span>
                      <span>{simulation.duration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Technology:</span>
                      <span>{simulation.technology}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Participants:</span>
                      <span>{simulation.participants}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Scenarios:</span>
                      <span>{simulation.scenarios.length}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Learning Objectives</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      {simulation.objectives.map((objective, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <Target className="h-3 w-3 text-blue-500 mt-1 flex-shrink-0" />
                          <span>{objective}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Safety Guidelines</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start space-x-2">
                        <AlertTriangle className="h-3 w-3 text-orange-500 mt-1 flex-shrink-0" />
                        <span>Clear physical space of obstacles</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <AlertTriangle className="h-3 w-3 text-orange-500 mt-1 flex-shrink-0" />
                        <span>Have supervisor present during VR</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <AlertTriangle className="h-3 w-3 text-orange-500 mt-1 flex-shrink-0" />
                        <span>Take breaks if experiencing motion sickness</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl mb-4">Simulation & Virtual Training Center</h2>
        <p className="text-gray-600 max-w-3xl mx-auto">
          Experience realistic disaster scenarios through cutting-edge simulation technology. 
          Practice your response skills in a safe, controlled environment with immersive VR, AR, and hybrid drills.
        </p>
      </div>

      <Tabs defaultValue="simulations" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="simulations">Virtual Simulations</TabsTrigger>
          <TabsTrigger value="hybrid">Hybrid Drills</TabsTrigger>
          <TabsTrigger value="results">Drill Results</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
        </TabsList>

        <TabsContent value="simulations" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {virtualSimulations.map((sim) => (
              <Card key={sim.id} className={`overflow-hidden ${!sim.available ? 'opacity-75' : 'hover:shadow-lg transition-shadow'}`}>
                <div className="aspect-video relative">
                  <ImageWithFallback 
                    src={sim.image} 
                    alt={sim.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4 space-x-2">
                    <Badge variant={sim.type === 'VR' ? 'default' : sim.type === 'AR' ? 'secondary' : 'destructive'}>
                      {sim.type}
                    </Badge>
                    {!sim.available && <Badge variant="outline">Coming Soon</Badge>}
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="outline" className="bg-white/90">{sim.difficulty}</Badge>
                  </div>
                </div>
                
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {sim.title}
                    <div className="flex items-center space-x-1 text-sm text-gray-500">
                      <Clock className="h-4 w-4" />
                      <span>{sim.duration}</span>
                    </div>
                  </CardTitle>
                  <CardDescription>{sim.description}</CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Technology:</span>
                      <p className="font-medium">{sim.technology}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Participants:</span>
                      <p className="font-medium">{sim.participants}</p>
                    </div>
                  </div>

                  <div>
                    <span className="text-sm text-gray-600">Available Scenarios:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {sim.scenarios.map((scenario, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {scenario}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-sm text-gray-600 mb-2 block">Learning Objectives:</span>
                    <ul className="space-y-1">
                      {sim.objectives.slice(0, 2).map((objective, index) => (
                        <li key={index} className="flex items-start space-x-2 text-sm">
                          <Target className="h-3 w-3 text-blue-500 mt-1 flex-shrink-0" />
                          <span className="text-gray-600">{objective}</span>
                        </li>
                      ))}
                      {sim.objectives.length > 2 && (
                        <li className="text-xs text-gray-500">+{sim.objectives.length - 2} more objectives</li>
                      )}
                    </ul>
                  </div>

                  <Button 
                    className="w-full" 
                    disabled={!sim.available}
                    onClick={() => sim.available && setActiveSimulation(sim.id)}
                  >
                    {sim.available ? (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Start Simulation
                      </>
                    ) : (
                      <>
                        <Clock className="h-4 w-4 mr-2" />
                        Coming Soon
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-gradient-to-r from-purple-50 to-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Headphones className="h-5 w-5 text-purple-500" />
                <span>Technology Requirements</span>
              </CardTitle>
              <CardDescription>What you need to access our simulations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <Eye className="h-8 w-8 text-blue-500 mx-auto mb-3" />
                  <h4 className="mb-2">VR Simulations</h4>
                  <p className="text-sm text-gray-600">Requires VR headset (Oculus, HTC Vive, or similar)</p>
                </div>
                <div className="text-center">
                  <Monitor className="h-8 w-8 text-green-500 mx-auto mb-3" />
                  <h4 className="mb-2">AR Experiences</h4>
                  <p className="text-sm text-gray-600">Works with smartphones and tablets (iOS/Android)</p>
                </div>
                <div className="text-center">
                  <Gamepad2 className="h-8 w-8 text-purple-500 mx-auto mb-3" />
                  <h4 className="mb-2">Mixed Reality</h4>
                  <p className="text-sm text-gray-600">Combines VR technology with physical props</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="hybrid" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Hybrid Training Drills</h3>
            <p className="text-gray-600">Combining digital learning with real-world practice for comprehensive preparedness</p>
          </div>

          <div className="space-y-6">
            {hybridDrills.map((drill) => (
              <Card key={drill.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center space-x-2">
                        <Zap className="h-5 w-5 text-orange-500" />
                        <span>{drill.title}</span>
                      </CardTitle>
                      <CardDescription>{drill.description}</CardDescription>
                    </div>
                    <Badge>{drill.type}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2">
                      <h4 className="mb-3 flex items-center space-x-2">
                        <Target className="h-4 w-4 text-blue-500" />
                        <span>Training Phases</span>
                      </h4>
                      <div className="space-y-3">
                        {drill.phases.map((phase, index) => (
                          <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                            <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="text-xs text-blue-600">{index + 1}</span>
                            </div>
                            <span className="text-sm">{phase}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-base">Session Details</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3 text-sm">
                          <div className="flex justify-between">
                            <span>Duration:</span>
                            <span>{drill.duration}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Participants:</span>
                            <span>{drill.participants}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Next Session:</span>
                            <span className="text-blue-600">{drill.nextSession}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Enrolled:</span>
                            <span>{drill.enrolled}/{drill.maxCapacity}</span>
                          </div>
                        </CardContent>
                      </Card>

                      <Button className="w-full">
                        <Users className="h-4 w-4 mr-2" />
                        Join Drill
                      </Button>
                      
                      {userType === 'teacher' && (
                        <Button variant="outline" className="w-full">
                          <Calendar className="h-4 w-4 mr-2" />
                          Schedule for Class
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Drill Performance & Results</h3>
            <p className="text-gray-600">Track progress and identify areas for improvement</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                <span>Recent Drill Results</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {drillResults.map((result) => (
                  <div key={result.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h4 className="mb-1">{result.drill}</h4>
                      <p className="text-sm text-gray-600">{result.date} • {result.participants} participants</p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">Avg Time</p>
                        <p className="font-medium">{result.avgTime}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">Score</p>
                        <Badge variant={result.score >= 90 ? 'default' : result.score >= 80 ? 'secondary' : 'destructive'}>
                          {result.score}%
                        </Badge>
                      </div>
                      <Button variant="outline" size="sm">View Details</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Performance Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Response Time</span>
                      <span className="text-green-600">↓ 12%</span>
                    </div>
                    <Progress value={75} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Accuracy</span>
                      <span className="text-green-600">↑ 8%</span>
                    </div>
                    <Progress value={88} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Participation</span>
                      <span className="text-green-600">↑ 15%</span>
                    </div>
                    <Progress value={92} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Areas for Improvement</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start space-x-2">
                    <AlertTriangle className="h-3 w-3 text-orange-500 mt-1 flex-shrink-0" />
                    <span>Evacuation route memorization</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <AlertTriangle className="h-3 w-3 text-orange-500 mt-1 flex-shrink-0" />
                    <span>Communication during emergencies</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <AlertTriangle className="h-3 w-3 text-orange-500 mt-1 flex-shrink-0" />
                    <span>Assisting others with disabilities</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Perfect Earthquake Drill</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Fast Evacuation Time</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm">Team Leadership</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Simulation Schedule</h3>
            <p className="text-gray-600">Upcoming drills and training sessions</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-blue-500" />
                <span>This Week's Sessions</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => (
                    <div key={day} className="text-center">
                      <h4 className="mb-2 text-sm font-medium">{day}</h4>
                      <div className="space-y-2">
                        {index === 2 && (
                          <div className="p-2 bg-blue-50 rounded text-xs">
                            <p className="font-medium">2:00 PM</p>
                            <p>Earthquake Drill</p>
                          </div>
                        )}
                        {index === 4 && (
                          <div className="p-2 bg-green-50 rounded text-xs">
                            <p className="font-medium">3:00 PM</p>
                            <p>VR Fire Safety</p>
                          </div>
                        )}
                        {index === 5 && (
                          <div className="p-2 bg-purple-50 rounded text-xs">
                            <p className="font-medium">10:00 AM</p>
                            <p>Community Flood</p>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {userType === 'teacher' && (
            <Card>
              <CardHeader>
                <CardTitle>Schedule New Drill</CardTitle>
                <CardDescription>Plan simulation sessions for your classes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="mb-3">Quick Schedule Options</h4>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <Target className="h-4 w-4 mr-2" />
                        Earthquake Drill - Tomorrow 2:00 PM
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Play className="h-4 w-4 mr-2" />
                        Fire Safety VR - Friday 3:00 PM
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Map className="h-4 w-4 mr-2" />
                        Evacuation Practice - Next Week
                      </Button>
                    </div>
                  </div>
                  <div>
                    <h4 className="mb-3">Custom Schedule</h4>
                    <Button className="w-full">
                      <Calendar className="h-4 w-4 mr-2" />
                      Open Schedule Builder
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
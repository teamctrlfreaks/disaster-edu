import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  BookOpen, 
  Trophy, 
  Target, 
  Zap, 
  CheckCircle, 
  Clock, 
  Play,
  Star,
  ArrowRight,
  Award,
  TrendingUp
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function StudentDashboard() {
  // Mock student data
  const studentData = {
    name: "Alex Chen",
    grade: "10th Grade",
    level: "Intermediate",
    points: 1890,
    rank: 3,
    completedModules: 12,
    totalModules: 18,
    preparednessScore: 78,
    streak: 7
  };

  const recentModules = [
    { id: 1, title: "Earthquake Safety Basics", type: "earthquake", completed: true, score: 92 },
    { id: 2, title: "Flood Response Techniques", type: "flood", completed: true, score: 88 },
    { id: 3, title: "Fire Emergency Procedures", type: "fire", completed: false, progress: 60 },
    { id: 4, title: "Cyclone Preparedness", type: "cyclone", completed: false, progress: 0 }
  ];

  const upcomingDrills = [
    { id: 1, title: "School Earthquake Drill", date: "Today, 2:00 PM", type: "earthquake" },
    { id: 2, title: "Fire Evacuation Practice", date: "Tomorrow, 10:30 AM", type: "fire" },
    { id: 3, title: "Virtual Flood Scenario", date: "Friday, 3:00 PM", type: "flood" }
  ];

  const achievements = [
    { id: 1, title: "First Aid Expert", icon: Award, color: "text-yellow-600 bg-yellow-100", earned: true },
    { id: 2, title: "Drill Master", icon: Target, color: "text-blue-600 bg-blue-100", earned: true },
    { id: 3, title: "Quick Learner", icon: Zap, color: "text-green-600 bg-green-100", earned: true },
    { id: 4, title: "Safety Champion", icon: Trophy, color: "text-purple-600 bg-purple-100", earned: false }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl mb-2">Welcome back, {studentData.name}!</h2>
            <p className="text-blue-100">Ready to continue your disaster preparedness journey?</p>
            <div className="flex items-center space-x-4 mt-4">
              <Badge variant="secondary" className="text-white bg-white/20">
                {studentData.grade}
              </Badge>
              <Badge variant="secondary" className="text-white bg-white/20">
                Level: {studentData.level}
              </Badge>
              <div className="flex items-center space-x-1">
                <Star className="h-4 w-4" />
                <span>{studentData.streak} day streak</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl mb-1">{studentData.points}</div>
            <div className="text-blue-100">Total Points</div>
            <Badge variant="secondary" className="mt-2 text-white bg-white/20">
              Rank #{studentData.rank}
            </Badge>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Modules Completed</p>
                <p className="text-2xl">{studentData.completedModules}/{studentData.totalModules}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Trophy className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Preparedness Score</p>
                <p className="text-2xl">{studentData.preparednessScore}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Target className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Drills Completed</p>
                <p className="text-2xl">8/10</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Learning Streak</p>
                <p className="text-2xl">{studentData.streak} days</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Continue Learning */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5" />
              <span>Continue Learning</span>
            </CardTitle>
            <CardDescription>Pick up where you left off</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentModules.map((module) => (
              <div key={module.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${
                    module.type === 'earthquake' ? 'bg-red-100' : 
                    module.type === 'flood' ? 'bg-blue-100' : 
                    module.type === 'fire' ? 'bg-orange-100' : 
                    'bg-gray-100'
                  }`}>
                    {module.completed ? (
                      <CheckCircle className={`h-5 w-5 ${
                        module.type === 'earthquake' ? 'text-red-600' : 
                        module.type === 'flood' ? 'text-blue-600' : 
                        module.type === 'fire' ? 'text-orange-600' : 
                        'text-gray-600'
                      }`} />
                    ) : (
                      <Clock className={`h-5 w-5 ${
                        module.type === 'earthquake' ? 'text-red-600' : 
                        module.type === 'flood' ? 'text-blue-600' : 
                        module.type === 'fire' ? 'text-orange-600' : 
                        'text-gray-600'
                      }`} />
                    )}
                  </div>
                  <div>
                    <h4 className="mb-1">{module.title}</h4>
                    {module.completed ? (
                      <Badge variant="outline" className="text-green-600">
                        Score: {module.score}%
                      </Badge>
                    ) : (
                      <div className="space-y-1">
                        <p className="text-sm text-gray-600">{module.progress}% complete</p>
                        <Progress value={module.progress} className="w-32" />
                      </div>
                    )}
                  </div>
                </div>
                <Button variant={module.completed ? "outline" : "default"} size="sm">
                  {module.completed ? "Review" : "Continue"}
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Upcoming Drills */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="h-5 w-5" />
              <span>Upcoming Drills</span>
            </CardTitle>
            <CardDescription>Stay prepared with practice sessions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {upcomingDrills.map((drill) => (
              <div key={drill.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${
                    drill.type === 'earthquake' ? 'bg-red-100' : 
                    drill.type === 'flood' ? 'bg-blue-100' : 
                    drill.type === 'fire' ? 'bg-orange-100' : 
                    'bg-gray-100'
                  }`}>
                    <Play className={`h-5 w-5 ${
                      drill.type === 'earthquake' ? 'text-red-600' : 
                      drill.type === 'flood' ? 'text-blue-600' : 
                      drill.type === 'fire' ? 'text-orange-600' : 
                      'text-gray-600'
                    }`} />
                  </div>
                  <div>
                    <h4 className="mb-1">{drill.title}</h4>
                    <p className="text-sm text-gray-600">{drill.date}</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  Join
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5" />
            <span>Recent Achievements</span>
          </CardTitle>
          <CardDescription>Your disaster preparedness milestones</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {achievements.map((achievement) => {
              const Icon = achievement.icon;
              return (
                <div key={achievement.id} className={`text-center p-4 rounded-lg border ${achievement.earned ? 'border-green-200 bg-green-50' : 'border-gray-200 opacity-50'}`}>
                  <div className={`p-3 rounded-full w-fit mx-auto mb-3 ${achievement.earned ? achievement.color : 'bg-gray-100'}`}>
                    <Icon className={`h-6 w-6 ${achievement.earned ? achievement.color.split(' ')[0] : 'text-gray-400'}`} />
                  </div>
                  <h4 className="text-sm mb-1">{achievement.title}</h4>
                  {achievement.earned && (
                    <Badge variant="outline" className="text-green-600 border-green-200">
                      Earned
                    </Badge>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="p-3 bg-blue-100 rounded-full w-fit mx-auto mb-4">
              <BookOpen className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="mb-2">Start New Module</h3>
            <p className="text-sm text-gray-600 mb-4">Begin learning about a new disaster type</p>
            <Button className="w-full">Explore Modules</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="p-3 bg-green-100 rounded-full w-fit mx-auto mb-4">
              <Play className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="mb-2">Practice Simulation</h3>
            <p className="text-sm text-gray-600 mb-4">Test your skills in virtual scenarios</p>
            <Button variant="outline" className="w-full">Start Simulation</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <div className="p-3 bg-orange-100 rounded-full w-fit mx-auto mb-4">
              <Trophy className="h-8 w-8 text-orange-600" />
            </div>
            <h3 className="mb-2">View Leaderboard</h3>
            <p className="text-sm text-gray-600 mb-4">See how you rank against classmates</p>
            <Button variant="outline" className="w-full">View Rankings</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
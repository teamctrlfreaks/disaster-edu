import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Users, 
  BookOpen, 
  Target, 
  TrendingUp, 
  Calendar, 
  AlertCircle,
  CheckCircle,
  Clock,
  BarChart3,
  FileText,
  MessageSquare,
  Settings
} from 'lucide-react';

export function TeacherDashboard() {
  // Mock teacher data
  const teacherData = {
    name: "Ms. Sarah Johnson",
    school: "Lincoln High School",
    classes: 4,
    totalStudents: 120,
    activeDrills: 3
  };

  const classStats = [
    { id: 1, name: "Grade 9A", students: 28, avgScore: 85, completed: 24, preparing: 4 },
    { id: 2, name: "Grade 9B", students: 30, avgScore: 78, completed: 26, preparing: 4 },
    { id: 3, name: "Grade 10A", students: 32, avgScore: 92, completed: 30, preparing: 2 },
    { id: 4, name: "Grade 10B", students: 30, avgScore: 88, completed: 28, preparing: 2 }
  ];

  const recentActivities = [
    { id: 1, type: "drill", student: "Alex Chen", activity: "Completed Earthquake Drill", score: 95, time: "2 hours ago" },
    { id: 2, type: "module", student: "Maria Lopez", activity: "Finished Flood Safety Module", score: 88, time: "3 hours ago" },
    { id: 3, type: "quiz", student: "David Kim", activity: "Took Fire Safety Quiz", score: 92, time: "5 hours ago" },
    { id: 4, type: "drill", student: "Emma Wilson", activity: "Participated in Evacuation Drill", score: 87, time: "1 day ago" }
  ];

  const upcomingDrills = [
    { id: 1, title: "School-wide Earthquake Drill", class: "All Classes", date: "Today, 2:00 PM", participants: 120 },
    { id: 2, title: "Fire Evacuation - Building A", class: "Grade 9A, 9B", date: "Tomorrow, 10:30 AM", participants: 58 },
    { id: 3, title: "Virtual Flood Response", class: "Grade 10A", date: "Friday, 3:00 PM", participants: 32 }
  ];

  const lowPerformers = [
    { name: "Jake Thompson", class: "Grade 9A", score: 65, modules: 8 },
    { name: "Lisa Park", class: "Grade 9B", score: 68, modules: 9 },
    { name: "Ryan Foster", class: "Grade 10B", score: 62, modules: 7 }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl mb-2">Welcome back, {teacherData.name}!</h2>
            <p className="text-green-100">Manage your classes and track student progress</p>
            <div className="flex items-center space-x-4 mt-4">
              <Badge variant="secondary" className="text-white bg-white/20">
                {teacherData.school}
              </Badge>
              <Badge variant="secondary" className="text-white bg-white/20">
                {teacherData.classes} Classes
              </Badge>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl mb-1">{teacherData.totalStudents}</div>
            <div className="text-green-100">Total Students</div>
            <Badge variant="secondary" className="mt-2 text-white bg-white/20">
              {teacherData.activeDrills} Active Drills
            </Badge>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Active Students</p>
                <p className="text-2xl">{teacherData.totalStudents}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Avg. Class Score</p>
                <p className="text-2xl">86%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Target className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Drills This Week</p>
                <p className="text-2xl">12</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <BookOpen className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Modules Available</p>
                <p className="text-2xl">18</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="classes" className="space-y-6">
        <TabsList>
          <TabsTrigger value="classes">Class Overview</TabsTrigger>
          <TabsTrigger value="drills">Drill Management</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
        </TabsList>

        <TabsContent value="classes" className="space-y-6">
          {/* Class Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="h-5 w-5" />
                <span>Class Performance Overview</span>
              </CardTitle>
              <CardDescription>Track progress across all your classes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {classStats.map((classItem) => (
                  <div key={classItem.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-lg">{classItem.name}</h4>
                      <Badge variant="outline">{classItem.students} students</Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-gray-600 mb-2">Average Score</p>
                        <div className="flex items-center space-x-2">
                          <Progress value={classItem.avgScore} className="flex-1" />
                          <span className="text-sm font-medium">{classItem.avgScore}%</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-center">
                          <p className="text-sm text-gray-600">Completed</p>
                          <p className="text-xl text-green-600">{classItem.completed}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm text-gray-600">In Progress</p>
                          <p className="text-xl text-orange-600">{classItem.preparing}</p>
                        </div>
                      </div>
                      <div className="space-x-2">
                        <Button variant="outline" size="sm">View Details</Button>
                        <Button size="sm">Manage Class</Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Students Needing Attention */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-orange-500" />
                <span>Students Needing Attention</span>
              </CardTitle>
              <CardDescription>Students with below-average performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {lowPerformers.map((student, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <div>
                      <h4 className="mb-1">{student.name}</h4>
                      <p className="text-sm text-gray-600">{student.class} • {student.modules} modules completed</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge variant="outline" className="text-orange-600">
                        {student.score}% avg
                      </Badge>
                      <Button variant="outline" size="sm">Contact</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="drills" className="space-y-6">
          {/* Upcoming Drills */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5" />
                <span>Upcoming Drills</span>
              </CardTitle>
              <CardDescription>Manage and schedule practice sessions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingDrills.map((drill) => (
                <div key={drill.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Target className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="mb-1">{drill.title}</h4>
                      <p className="text-sm text-gray-600">{drill.class} • {drill.date}</p>
                      <Badge variant="outline" className="mt-1">{drill.participants} participants</Badge>
                    </div>
                  </div>
                  <div className="space-x-2">
                    <Button variant="outline" size="sm">Edit</Button>
                    <Button size="sm">Start Drill</Button>
                  </div>
                </div>
              ))}
              <Button className="w-full mt-4">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule New Drill
              </Button>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>Recent Student Activity</span>
              </CardTitle>
              <CardDescription>Latest completions and achievements</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      activity.type === 'drill' ? 'bg-blue-100' : 
                      activity.type === 'module' ? 'bg-green-100' : 
                      'bg-purple-100'
                    }`}>
                      {activity.type === 'drill' ? (
                        <Target className={`h-4 w-4 ${
                          activity.type === 'drill' ? 'text-blue-600' : 
                          activity.type === 'module' ? 'text-green-600' : 
                          'text-purple-600'
                        }`} />
                      ) : activity.type === 'module' ? (
                        <BookOpen className="h-4 w-4 text-green-600" />
                      ) : (
                        <FileText className="h-4 w-4 text-purple-600" />
                      )}
                    </div>
                    <div>
                      <h4 className="mb-1">{activity.student}</h4>
                      <p className="text-sm text-gray-600">{activity.activity}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline" className="text-green-600 mb-1">
                      {activity.score}%
                    </Badge>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          {/* Performance Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5" />
                  <span>Class Performance Trends</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>This Week</span>
                      <span>86% avg</span>
                    </div>
                    <Progress value={86} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Last Week</span>
                      <span>82% avg</span>
                    </div>
                    <Progress value={82} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Last Month</span>
                      <span>79% avg</span>
                    </div>
                    <Progress value={79} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Module Completion Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Earthquake Safety</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={95} className="w-20" />
                      <span className="text-sm">95%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Fire Safety</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={88} className="w-20" />
                      <span className="text-sm">88%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Flood Response</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={76} className="w-20" />
                      <span className="text-sm">76%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Cyclone Preparedness</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={62} className="w-20" />
                      <span className="text-sm">62%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="resources" className="space-y-6">
          {/* Teaching Resources */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <span>Lesson Plans</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    Earthquake Safety Basics
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Flood Response Techniques
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Fire Emergency Procedures
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    First Aid Fundamentals
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5" />
                  <span>Communication</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button className="w-full">Send Class Message</Button>
                  <Button variant="outline" className="w-full">Parent Notifications</Button>
                  <Button variant="outline" className="w-full">Emergency Contacts</Button>
                  <Button variant="outline" className="w-full">Report Center</Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="h-5 w-5" />
                  <span>Settings</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    Class Preferences
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Notification Settings
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Grade Export
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Backup Data
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  BookOpen, 
  Heart, 
  TrendingUp, 
  Users, 
  MapPin, 
  Clock, 
  Star,
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  Calendar,
  Globe,
  Award
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function CaseStudies() {
  // Mock case study data
  const pastDisasters = [
    {
      id: 1,
      title: "2011 Tōhoku Earthquake and Tsunami",
      location: "Japan",
      date: "March 11, 2011",
      type: "Earthquake & Tsunami",
      severity: "Magnitude 9.0",
      category: "earthquake",
      impact: "15,899 deaths, 2,526 missing",
      lessonsLearned: [
        "Early warning systems saved thousands of lives",
        "Community evacuation drills were crucial",
        "Infrastructure resilience prevented greater casualties",
        "International cooperation enhanced rescue efforts"
      ],
      heroStory: {
        title: "Miki Endo: The Voice of Minami-Sanriku",
        description: "Emergency broadcast announcer who continued warning residents until the last moment, saving countless lives.",
        impact: "Her announcements helped evacuate thousands before the tsunami hit."
      },
      innovations: [
        "Improved tsunami detection systems",
        "Enhanced building codes for earthquakes",
        "Better evacuation route planning"
      ],
      image: "https://images.unsplash.com/photo-1588396130815-0ccfa8d8fec4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400"
    },
    {
      id: 2,
      title: "Hurricane Katrina",
      location: "New Orleans, USA",
      date: "August 29, 2005",
      type: "Hurricane",
      severity: "Category 5",
      category: "hurricane",
      impact: "1,833 deaths, $125 billion damage",
      lessonsLearned: [
        "Evacuation planning needs to account for all populations",
        "Levee systems require regular maintenance and upgrades",
        "Communication between agencies is critical",
        "Community preparedness varies by socioeconomic status"
      ],
      heroStory: {
        title: "The Cajun Navy",
        description: "Volunteer rescuers who used personal boats to save thousands of people trapped by floodwaters.",
        impact: "Rescued over 10,000 people when official rescue operations were overwhelmed."
      },
      innovations: [
        "Improved hurricane forecasting",
        "Better emergency communication systems",
        "Enhanced levee and flood protection"
      ],
      image: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400"
    },
    {
      id: 3,
      title: "2019-2020 Australian Bushfires",
      location: "Australia",
      date: "September 2019 - March 2020",
      type: "Wildfire",
      severity: "18.6 million hectares burned",
      category: "fire",
      impact: "34 deaths, 3,500+ homes destroyed",
      lessonsLearned: [
        "Climate change increases fire risk significantly",
        "Early warning systems and evacuation plans save lives",
        "Community fire preparedness is essential",
        "Wildlife protection requires special consideration"
      ],
      heroStory: {
        title: "Rural Fire Service Volunteers",
        description: "Thousands of volunteer firefighters who risked their lives to protect communities and wildlife.",
        impact: "Volunteers made up 90% of firefighting efforts, working tirelessly for months."
      },
      innovations: [
        "Advanced fire weather forecasting",
        "Improved evacuation alert systems",
        "Better community shelters and refuges"
      ],
      image: "https://images.unsplash.com/photo-1572996489045-96ed977a73b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400"
    },
    {
      id: 4,
      title: "Kerala Floods 2018",
      location: "Kerala, India",
      date: "August 2018",
      type: "Flood",
      severity: "Worst floods in a century",
      category: "flood",
      impact: "483 deaths, 1.4 million displaced",
      lessonsLearned: [
        "Social media became crucial for rescue coordination",
        "Community solidarity was key to recovery",
        "Dam management policies need improvement",
        "Fisher community knowledge proved invaluable"
      ],
      heroStory: {
        title: "Kerala Fishermen",
        description: "Local fishermen who navigated dangerous floodwaters to rescue stranded people using their boats and local knowledge.",
        impact: "Rescued over 65,000 people in the most dangerous conditions."
      },
      innovations: [
        "Community-based early warning systems",
        "Social media rescue coordination",
        "Improved dam management protocols"
      ],
      image: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400"
    }
  ];

  const heroProfiles = [
    {
      id: 1,
      name: "Captain Chesley 'Sully' Sullenberger",
      role: "Pilot, US Airways Flight 1549",
      achievement: "Successfully landed damaged aircraft on Hudson River, saving all 155 lives",
      disaster: "Aviation Emergency",
      year: "2009",
      lesson: "Quick thinking, training, and calm leadership in crisis situations",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=150"
    },
    {
      id: 2,
      name: "Witold Pilecki",
      role: "Polish Officer & Resistance Fighter",
      achievement: "Voluntarily entered Auschwitz to organize resistance and report on Holocaust",
      disaster: "War & Human Rights Crisis",
      year: "1940-1943",
      lesson: "Courage to act when others cannot, importance of bearing witness",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=150"
    },
    {
      id: 3,
      name: "Dr. Li Wenliang",
      role: "Ophthalmologist, Wuhan Central Hospital",
      achievement: "Early warning about COVID-19 outbreak despite government pressure",
      disaster: "Pandemic",
      year: "2019-2020",
      lesson: "Importance of scientific integrity and early warning systems",
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=150"
    },
    {
      id: 4,
      name: "Irena Sendler",
      role: "Polish Nurse & Social Worker",
      achievement: "Saved 2,500 Jewish children from Warsaw Ghetto during Holocaust",
      disaster: "War & Genocide",
      year: "1940-1943",
      lesson: "Individual actions can save many lives, importance of documenting rescue efforts",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=150"
    }
  ];

  const communitySuccess = [
    {
      id: 1,
      community: "Sendai, Japan",
      challenge: "Tsunami Risk Management",
      solution: "Comprehensive disaster education and early warning systems",
      outcome: "Significantly reduced casualties during 2011 tsunami",
      keyFactors: [
        "Regular evacuation drills in schools",
        "Community-based disaster preparedness",
        "Investment in early warning technology",
        "Cultural emphasis on collective responsibility"
      ]
    },
    {
      id: 2,
      community: "Bangladesh Cyclone Preparedness",
      challenge: "Recurring Cyclone Threats",
      solution: "Network of community volunteers and shelters",
      outcome: "Death toll reduced from thousands to hundreds per cyclone",
      keyFactors: [
        "Trained community volunteers",
        "Strategically located cyclone shelters",
        "Early warning dissemination",
        "Women's participation in disaster management"
      ]
    },
    {
      id: 3,
      community: "California Wildfire Communities",
      challenge: "Increasing Wildfire Risk",
      solution: "Defensible space and community fire plans",
      outcome: "Many communities successfully defended against major fires",
      keyFactors: [
        "Vegetation management around homes",
        "Community firefighting equipment",
        "Evacuation planning and practice",
        "Collaboration with fire services"
      ]
    }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl mb-4">Case Studies & Learning from the Past</h2>
        <p className="text-gray-600 max-w-3xl mx-auto">
          Explore real disaster events, learn from community responses, and discover how heroes emerged 
          in times of crisis. Understanding past events helps us prepare for future challenges.
        </p>
      </div>

      <Tabs defaultValue="disasters" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="disasters">Past Disasters</TabsTrigger>
          <TabsTrigger value="heroes">Hero Stories</TabsTrigger>
          <TabsTrigger value="communities">Community Success</TabsTrigger>
          <TabsTrigger value="lessons">Key Lessons</TabsTrigger>
        </TabsList>

        <TabsContent value="disasters" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {pastDisasters.map((disaster) => (
              <Card key={disaster.id} className="overflow-hidden">
                <div className="aspect-video relative">
                  <ImageWithFallback 
                    src={disaster.image} 
                    alt={disaster.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant="destructive">{disaster.type}</Badge>
                  </div>
                </div>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{disaster.title}</CardTitle>
                      <CardDescription className="flex items-center space-x-4 mt-2">
                        <span className="flex items-center space-x-1">
                          <MapPin className="h-4 w-4" />
                          <span>{disaster.location}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span>{disaster.date}</span>
                        </span>
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="mb-2 flex items-center space-x-2">
                      <AlertTriangle className="h-4 w-4 text-orange-500" />
                      <span>Impact</span>
                    </h4>
                    <p className="text-sm text-gray-600">{disaster.impact}</p>
                  </div>

                  <div>
                    <h4 className="mb-2 flex items-center space-x-2">
                      <Heart className="h-4 w-4 text-red-500" />
                      <span>Hero Story</span>
                    </h4>
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <h5 className="text-sm mb-1">{disaster.heroStory.title}</h5>
                      <p className="text-xs text-gray-600 mb-2">{disaster.heroStory.description}</p>
                      <p className="text-xs text-blue-700">{disaster.heroStory.impact}</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="mb-2 flex items-center space-x-2">
                      <TrendingUp className="h-4 w-4 text-green-500" />
                      <span>Key Lessons</span>
                    </h4>
                    <ul className="text-sm space-y-1">
                      {disaster.lessonsLearned.slice(0, 2).map((lesson, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="h-3 w-3 text-green-500 mt-1 flex-shrink-0" />
                          <span className="text-gray-600">{lesson}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button variant="outline" className="w-full">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Read Full Case Study
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="heroes" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Heroes & Inspirational Stories</h3>
            <p className="text-gray-600">Learn from individuals who showed extraordinary courage and leadership during crises</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {heroProfiles.map((hero) => (
              <Card key={hero.id}>
                <CardHeader>
                  <div className="flex items-start space-x-4">
                    <ImageWithFallback 
                      src={hero.image} 
                      alt={hero.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <CardTitle className="text-lg">{hero.name}</CardTitle>
                      <CardDescription>{hero.role}</CardDescription>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant="outline">{hero.disaster}</Badge>
                        <Badge variant="outline">{hero.year}</Badge>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="mb-2 flex items-center space-x-2">
                      <Award className="h-4 w-4 text-yellow-500" />
                      <span>Achievement</span>
                    </h4>
                    <p className="text-sm text-gray-600">{hero.achievement}</p>
                  </div>

                  <div>
                    <h4 className="mb-2 flex items-center space-x-2">
                      <Star className="h-4 w-4 text-blue-500" />
                      <span>Lesson for Today</span>
                    </h4>
                    <p className="text-sm text-blue-700 bg-blue-50 p-3 rounded-lg">{hero.lesson}</p>
                  </div>

                  <Button variant="outline" className="w-full">
                    <Heart className="h-4 w-4 mr-2" />
                    Read Full Story
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Heart className="h-5 w-5 text-red-500" />
                <span>Become a Hero in Your Community</span>
              </CardTitle>
              <CardDescription>You don't need to wait for a disaster to make a difference</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4">
                  <Users className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                  <h4 className="mb-2">Volunteer Training</h4>
                  <p className="text-sm text-gray-600">Join emergency response teams</p>
                </div>
                <div className="text-center p-4">
                  <BookOpen className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <h4 className="mb-2">Educate Others</h4>
                  <p className="text-sm text-gray-600">Teach disaster preparedness</p>
                </div>
                <div className="text-center p-4">
                  <Globe className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <h4 className="mb-2">Build Networks</h4>
                  <p className="text-sm text-gray-600">Create community connections</p>
                </div>
              </div>
              <Button className="w-full mt-4">
                <ArrowRight className="h-4 w-4 mr-2" />
                Explore Volunteer Opportunities
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="communities" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Community Success Stories</h3>
            <p className="text-gray-600">Learn how communities successfully prepared for and responded to disasters</p>
          </div>

          <div className="space-y-6">
            {communitySuccess.map((success) => (
              <Card key={success.id}>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MapPin className="h-5 w-5 text-blue-500" />
                    <span>{success.community}</span>
                  </CardTitle>
                  <CardDescription>{success.challenge}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <h4 className="mb-2 flex items-center space-x-2">
                          <TrendingUp className="h-4 w-4 text-green-500" />
                          <span>Solution Implemented</span>
                        </h4>
                        <p className="text-sm text-gray-600">{success.solution}</p>
                      </div>

                      <div>
                        <h4 className="mb-2 flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-blue-500" />
                          <span>Outcome</span>
                        </h4>
                        <p className="text-sm text-blue-700 bg-blue-50 p-3 rounded-lg">{success.outcome}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="mb-3 flex items-center space-x-2">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span>Key Success Factors</span>
                      </h4>
                      <ul className="space-y-2">
                        {success.keyFactors.map((factor, index) => (
                          <li key={index} className="flex items-start space-x-2 text-sm">
                            <CheckCircle className="h-3 w-3 text-green-500 mt-1 flex-shrink-0" />
                            <span className="text-gray-600">{factor}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-gradient-to-r from-green-50 to-blue-50">
            <CardHeader>
              <CardTitle>Apply These Lessons to Your Community</CardTitle>
              <CardDescription>Adapt successful strategies to your local context</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="mb-3">Start in Your Neighborhood</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Organize preparedness meetings</li>
                    <li>• Create communication networks</li>
                    <li>• Share resources and knowledge</li>
                    <li>• Practice evacuation routes</li>
                  </ul>
                </div>
                <div>
                  <h4 className="mb-3">Partner with Local Authorities</h4>
                  <ul className="space-y-2 text-sm">
                    <li>• Connect with emergency services</li>
                    <li>• Advocate for early warning systems</li>
                    <li>• Support infrastructure improvements</li>
                    <li>• Participate in community drills</li>
                  </ul>
                </div>
              </div>
              <div className="flex space-x-4 mt-6">
                <Button>
                  <Users className="h-4 w-4 mr-2" />
                  Start Community Group
                </Button>
                <Button variant="outline">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Download Planning Guide
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lessons" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-xl mb-2">Universal Lessons from Disasters</h3>
            <p className="text-gray-600">Key insights that apply across different types of disasters and communities</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-blue-500" />
                  <span>Early Warning Saves Lives</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Every minute counts in disaster response. Communities with effective early warning systems 
                  consistently have lower casualty rates.
                </p>
                <ul className="text-xs space-y-1">
                  <li>• Invest in detection technology</li>
                  <li>• Train people to recognize natural warnings</li>
                  <li>• Ensure warnings reach everyone</li>
                  <li>• Practice responding to warnings</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-green-500" />
                  <span>Community Preparation</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Well-prepared communities recover faster and experience fewer casualties. 
                  Social connections are as important as physical infrastructure.
                </p>
                <ul className="text-xs space-y-1">
                  <li>• Know your neighbors</li>
                  <li>• Share resources and knowledge</li>
                  <li>• Practice together regularly</li>
                  <li>• Include everyone in planning</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-purple-500" />
                  <span>Learning from Experience</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Communities that learn from past events and continuously improve their 
                  preparedness become increasingly resilient over time.
                </p>
                <ul className="text-xs space-y-1">
                  <li>• Conduct post-event reviews</li>
                  <li>• Update plans based on lessons</li>
                  <li>• Share knowledge with others</li>
                  <li>• Invest in long-term resilience</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  <span>Leadership in Crisis</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Heroes emerge at all levels during disasters. Leadership can come from 
                  anyone who takes initiative to help others.
                </p>
                <ul className="text-xs space-y-1">
                  <li>• Stay calm under pressure</li>
                  <li>• Put others' safety first</li>
                  <li>• Make quick, informed decisions</li>
                  <li>• Communicate clearly and often</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Globe className="h-5 w-5 text-teal-500" />
                  <span>Global Cooperation</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Disasters don't respect borders. International cooperation and 
                  knowledge sharing improve global disaster resilience.
                </p>
                <ul className="text-xs space-y-1">
                  <li>• Share early warning information</li>
                  <li>• Coordinate rescue efforts</li>
                  <li>• Exchange best practices</li>
                  <li>• Support vulnerable regions</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="h-5 w-5 text-yellow-500" />
                  <span>Training & Education</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Regular training and education create muscle memory for emergency 
                  response and build confidence in crisis situations.
                </p>
                <ul className="text-xs space-y-1">
                  <li>• Practice makes perfect</li>
                  <li>• Train for realistic scenarios</li>
                  <li>• Update skills regularly</li>
                  <li>• Include psychological preparation</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-to-r from-yellow-50 to-orange-50">
            <CardHeader>
              <CardTitle>Apply These Lessons Today</CardTitle>
              <CardDescription>Don't wait for a disaster to start preparing</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="mb-3">Personal Actions</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Create a family emergency plan</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Build an emergency kit</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Learn first aid and CPR</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>Stay informed about local risks</span>
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="mb-3">Community Actions</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-blue-500" />
                      <span>Organize neighborhood preparedness</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-blue-500" />
                      <span>Advocate for early warning systems</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-blue-500" />
                      <span>Support vulnerable community members</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-blue-500" />
                      <span>Participate in community drills</span>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="flex space-x-4 mt-6">
                <Button>
                  <ArrowRight className="h-4 w-4 mr-2" />
                  Start Your Preparedness Journey
                </Button>
                <Button variant="outline">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Download Action Checklist
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { Badge } from './components/ui/badge';
import { Progress } from './components/ui/progress';
import { Alert, AlertDescription } from './components/ui/alert';
import { 
  Home, 
  GraduationCap, 
  Users, 
  BookOpen, 
  Trophy, 
  Shield, 
  Gamepad2, 
  FileText, 
  MapPin, 
  Bell,
  Play,
  Star,
  Award,
  Target,
  Zap,
  Heart,
  MessageCircle
} from 'lucide-react';
import { StudentDashboard } from './components/student-dashboard';
import { TeacherDashboard } from './components/teacher-dashboard';
import { CommunityDashboard } from './components/community-dashboard';
import { InteractiveModules } from './components/interactive-modules';
import { CaseStudies } from './components/case-studies';
import { SimulationCenter } from './components/simulation-center';
import { ResourceCenter } from './components/resource-center';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

export default function App() {
  const [currentUser, setCurrentUser] = useState<'student' | 'teacher' | 'community' | null>(null);
  const [activeTab, setActiveTab] = useState('home');

  // Mock alert data
  const activeAlerts = [
    { id: 1, type: 'Cyclone Warning', region: 'Coastal Areas', severity: 'High', time: '2 hours ago' },
    { id: 2, type: 'Flood Alert', region: 'River Basin', severity: 'Medium', time: '6 hours ago' }
  ];

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-xl">DisasterEd Pro</h1>
              </div>
              <div className="flex items-center space-x-2">
                <Bell className="h-5 w-5 text-orange-500" />
                <Badge variant="destructive">{activeAlerts.length}</Badge>
              </div>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <div className="relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
            <div className="text-center">
              <h1 className="text-4xl tracking-tight text-gray-900 sm:text-6xl">
                Disaster Preparedness
                <span className="text-blue-600"> Education Platform</span>
              </h1>
              <p className="mt-6 text-lg leading-8 text-gray-600 max-w-3xl mx-auto">
                Empowering students, teachers, and communities with essential disaster preparedness knowledge through interactive learning, gamified experiences, and real-time emergency guidance.
              </p>
              
              {/* User Type Selection */}
              <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setCurrentUser('student')}>
                  <CardHeader className="text-center">
                    <div className="mx-auto p-3 bg-blue-100 rounded-full w-fit">
                      <GraduationCap className="h-8 w-8 text-blue-600" />
                    </div>
                    <CardTitle>For Students</CardTitle>
                    <CardDescription>
                      Interactive learning modules, quizzes, and gamified disaster preparedness education
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Adaptive learning paths</li>
                      <li>• Virtual disaster scenarios</li>
                      <li>• Badges & achievements</li>
                      <li>• Knowledge testing</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setCurrentUser('teacher')}>
                  <CardHeader className="text-center">
                    <div className="mx-auto p-3 bg-green-100 rounded-full w-fit">
                      <BookOpen className="h-8 w-8 text-green-600" />
                    </div>
                    <CardTitle>For Teachers</CardTitle>
                    <CardDescription>
                      Comprehensive teaching tools, student progress tracking, and drill management
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Class management</li>
                      <li>• Progress analytics</li>
                      <li>• Lesson plans & resources</li>
                      <li>• Virtual drill tools</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setCurrentUser('community')}>
                  <CardHeader className="text-center">
                    <div className="mx-auto p-3 bg-purple-100 rounded-full w-fit">
                      <Users className="h-8 w-8 text-purple-600" />
                    </div>
                    <CardTitle>For Community</CardTitle>
                    <CardDescription>
                      Family safety guides, community engagement, and parent dashboard access
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>• Family safety checklists</li>
                      <li>• Community forums</li>
                      <li>• Emergency contacts</li>
                      <li>• Child progress tracking</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              {/* Platform Features */}
              <div className="mt-24">
                <h2 className="text-2xl text-center mb-12 text-gray-900">Platform Features</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  <div className="text-center">
                    <div className="mx-auto p-3 bg-orange-100 rounded-full w-fit mb-4">
                      <Gamepad2 className="h-6 w-6 text-orange-600" />
                    </div>
                    <h3 className="mb-2">Gamified Learning</h3>
                    <p className="text-sm text-gray-600">Engaging experiences with badges, rankings, and challenges</p>
                  </div>
                  <div className="text-center">
                    <div className="mx-auto p-3 bg-red-100 rounded-full w-fit mb-4">
                      <Target className="h-6 w-6 text-red-600" />
                    </div>
                    <h3 className="mb-2">Virtual Simulations</h3>
                    <p className="text-sm text-gray-600">Immersive AR/VR disaster scenarios and practice drills</p>
                  </div>
                  <div className="text-center">
                    <div className="mx-auto p-3 bg-teal-100 rounded-full w-fit mb-4">
                      <Zap className="h-6 w-6 text-teal-600" />
                    </div>
                    <h3 className="mb-2">Real-time Alerts</h3>
                    <p className="text-sm text-gray-600">Live disaster warnings and emergency notifications</p>
                  </div>
                  <div className="text-center">
                    <div className="mx-auto p-3 bg-pink-100 rounded-full w-fit mb-4">
                      <Heart className="h-6 w-6 text-pink-600" />
                    </div>
                    <h3 className="mb-2">Hero Stories</h3>
                    <p className="text-sm text-gray-600">Inspiring tales of survival and community resilience</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-600 rounded-lg">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <h1 className="text-lg">DisasterEd Pro</h1>
            </div>

            {/* Active Alerts */}
            {activeAlerts.length > 0 && (
              <div className="flex items-center space-x-2">
                <Bell className="h-4 w-4 text-orange-500 animate-pulse" />
                <Badge variant="destructive">{activeAlerts.length} Active Alerts</Badge>
              </div>
            )}

            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="capitalize">{currentUser}</Badge>
              <Button variant="outline" size="sm" onClick={() => setCurrentUser(null)}>
                Switch User
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Active Alerts Bar */}
      {activeAlerts.length > 0 && (
        <div className="bg-orange-50 border-b border-orange-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                {activeAlerts.slice(0, 2).map((alert) => (
                  <Alert key={alert.id} className="border-orange-200 bg-white/50">
                    <AlertDescription className="text-sm">
                      <span className="text-red-600">{alert.type}</span> in {alert.region} - {alert.severity} severity ({alert.time})
                    </AlertDescription>
                  </Alert>
                ))}
              </div>
              <Button variant="outline" size="sm">View All Alerts</Button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="home" className="flex items-center space-x-2">
              <Home className="h-4 w-4" />
              <span>Home</span>
            </TabsTrigger>
            <TabsTrigger value="modules" className="flex items-center space-x-2">
              <BookOpen className="h-4 w-4" />
              <span>Modules</span>
            </TabsTrigger>
            <TabsTrigger value="simulations" className="flex items-center space-x-2">
              <Gamepad2 className="h-4 w-4" />
              <span>Simulations</span>
            </TabsTrigger>
            <TabsTrigger value="cases" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Case Studies</span>
            </TabsTrigger>
            <TabsTrigger value="resources" className="flex items-center space-x-2">
              <MapPin className="h-4 w-4" />
              <span>Resources</span>
            </TabsTrigger>
            <TabsTrigger value="community" className="flex items-center space-x-2">
              <MessageCircle className="h-4 w-4" />
              <span>Community</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <Trophy className="h-4 w-4" />
              <span>Profile</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="home">
            {currentUser === 'student' && <StudentDashboard />}
            {currentUser === 'teacher' && <TeacherDashboard />}
            {currentUser === 'community' && <CommunityDashboard />}
          </TabsContent>

          <TabsContent value="modules">
            <InteractiveModules userType={currentUser} />
          </TabsContent>

          <TabsContent value="simulations">
            <SimulationCenter userType={currentUser} />
          </TabsContent>

          <TabsContent value="cases">
            <CaseStudies />
          </TabsContent>

          <TabsContent value="resources">
            <ResourceCenter userType={currentUser} />
          </TabsContent>

          <TabsContent value="community">
            <div className="space-y-6">
              <h2 className="text-2xl">Community Hub</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Discussion Forums</CardTitle>
                    <CardDescription>Connect with other community members</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <h4 className="mb-2">Recent Earthquake Preparedness Tips</h4>
                        <p className="text-sm text-gray-600">Discussion about home safety measures...</p>
                        <div className="flex items-center mt-2 space-x-4 text-xs text-gray-500">
                          <span>Posted by Sarah M.</span>
                          <span>23 replies</span>
                          <span>2 hours ago</span>
                        </div>
                      </div>
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <h4 className="mb-2">Flood Response Success Stories</h4>
                        <p className="text-sm text-gray-600">Sharing experiences from recent floods...</p>
                        <div className="flex items-center mt-2 space-x-4 text-xs text-gray-500">
                          <span>Posted by David K.</span>
                          <span>15 replies</span>
                          <span>1 day ago</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Volunteer Opportunities</CardTitle>
                    <CardDescription>Join community disaster response efforts</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 border rounded-lg">
                        <h4 className="mb-2">Emergency Response Training</h4>
                        <p className="text-sm text-gray-600 mb-2">Join our next community training session</p>
                        <Badge variant="outline">This Weekend</Badge>
                      </div>
                      <div className="p-4 border rounded-lg">
                        <h4 className="mb-2">School Safety Program</h4>
                        <p className="text-sm text-gray-600 mb-2">Help teach disaster preparedness in local schools</p>
                        <Badge variant="outline">Ongoing</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="profile">
            <div className="space-y-6">
              <h2 className="text-2xl">Profile & Achievements</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Progress Overview</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Overall Preparedness</span>
                        <span>78%</span>
                      </div>
                      <Progress value={78} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Modules Completed</span>
                        <span>12/18</span>
                      </div>
                      <Progress value={67} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Drills Participated</span>
                        <span>8/10</span>
                      </div>
                      <Progress value={80} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Achievements</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="p-2 bg-yellow-100 rounded-full w-fit mx-auto mb-2">
                          <Award className="h-6 w-6 text-yellow-600" />
                        </div>
                        <p className="text-xs">First Aid Expert</p>
                      </div>
                      <div className="text-center">
                        <div className="p-2 bg-blue-100 rounded-full w-fit mx-auto mb-2">
                          <Target className="h-6 w-6 text-blue-600" />
                        </div>
                        <p className="text-xs">Drill Master</p>
                      </div>
                      <div className="text-center">
                        <div className="p-2 bg-green-100 rounded-full w-fit mx-auto mb-2">
                          <Star className="h-6 w-6 text-green-600" />
                        </div>
                        <p className="text-xs">Top Learner</p>
                      </div>
                      <div className="text-center opacity-50">
                        <div className="p-2 bg-gray-100 rounded-full w-fit mx-auto mb-2">
                          <Trophy className="h-6 w-6 text-gray-400" />
                        </div>
                        <p className="text-xs">Hero Helper</p>
                      </div>
                      <div className="text-center opacity-50">
                        <div className="p-2 bg-gray-100 rounded-full w-fit mx-auto mb-2">
                          <Shield className="h-6 w-6 text-gray-400" />
                        </div>
                        <p className="text-xs">Safety Champion</p>
                      </div>
                      <div className="text-center opacity-50">
                        <div className="p-2 bg-gray-100 rounded-full w-fit mx-auto mb-2">
                          <Zap className="h-6 w-6 text-gray-400" />
                        </div>
                        <p className="text-xs">Quick Responder</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Leaderboard</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Badge variant="secondary">1</Badge>
                          <span className="text-sm">Alex Chen</span>
                        </div>
                        <span className="text-sm">2,450 pts</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Badge variant="secondary">2</Badge>
                          <span className="text-sm">Maria Lopez</span>
                        </div>
                        <span className="text-sm">2,180 pts</span>
                      </div>
                      <div className="flex items-center justify-between bg-blue-50 p-2 rounded">
                        <div className="flex items-center space-x-2">
                          <Badge>3</Badge>
                          <span className="text-sm">You</span>
                        </div>
                        <span className="text-sm">1,890 pts</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">4</Badge>
                          <span className="text-sm">David Kim</span>
                        </div>
                        <span className="text-sm">1,650 pts</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}